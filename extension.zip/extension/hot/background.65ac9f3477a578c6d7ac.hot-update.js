"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("15f4db253655f2932740")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.65ac9f3477a578c6d7ac.hot-update.js.map