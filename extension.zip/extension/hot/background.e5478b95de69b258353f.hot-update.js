"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("f3df52dfd65e6082d29e")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.e5478b95de69b258353f.hot-update.js.map