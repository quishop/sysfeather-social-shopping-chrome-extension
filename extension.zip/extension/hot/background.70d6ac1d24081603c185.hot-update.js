"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("75ecaff1993f86444cf9")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.70d6ac1d24081603c185.hot-update.js.map