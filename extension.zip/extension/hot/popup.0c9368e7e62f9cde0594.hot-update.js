"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("popup",{

/***/ "./src/popup/App.tsx":
/*!***************************!*\
  !*** ./src/popup/App.tsx ***!
  \***************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_es_list__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! antd/es/list */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/list/index.js");
/* harmony import */ var antd_es_space__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! antd/es/space */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/space/index.js");
/* harmony import */ var antd_es_avatar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd/es/avatar */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/avatar/index.js");
/* harmony import */ var antd_es_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd/es/typography */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/typography/index.js");
/* harmony import */ var antd_es_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! antd/es/layout */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/layout/index.js");
/* harmony import */ var _App_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.scss */ "./src/popup/App.scss");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js */ "./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js");











var _jsxFileName = "/Users/wadejhao/Documents/sysfeather-social-shopping-chrome-extension/src/popup/App.tsx";


const {
  Header,
  Content
} = antd_es_layout__WEBPACK_IMPORTED_MODULE_2__["default"];
const {
  Title,
  Paragraph
} = antd_es_typography__WEBPACK_IMPORTED_MODULE_3__["default"];
const data = ['https://www.facebook.com/groups/{社團名稱/ID}/permalink/{貼文ID}/', 'https://www.facebook.com/groups/{社團名稱/ID}/posts/{貼文ID}/'];
const App = () => {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)("div", {
    className: "app",
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd_es_layout__WEBPACK_IMPORTED_MODULE_2__["default"], {
      style: {
        background: '#fff'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Header, {
        style: {
          background: '#fff',
          display: 'flex',
          alignItems: 'center'
        },
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd_es_avatar__WEBPACK_IMPORTED_MODULE_4__["default"], {
          src: "icons/extension-icon-x128.png",
          size: "large"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 17,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Title, {
          level: 3,
          style: {
            margin: '0 0 0 10px'
          },
          children: "\u77FD\u7FBD+1\u667A\u6167\u5C0F\u5E6B\u624B"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Content, {
        style: {
          padding: '20px'
        },
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Title, {
          level: 4,
          children: "\u793E\u5718\u8CBC\u6587+1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 23,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(Paragraph, {
          children: "\u8ACB\u5728\u4EE5\u4E0B\u683C\u5F0F\u7DB2\u5740\u5C0E\u51FA\u793E\u5718\u8CBC\u6587\u548C\u7559\u8A00\uFF1A"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 21
        }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd_es_list__WEBPACK_IMPORTED_MODULE_5__["default"], {
          bordered: true,
          dataSource: data,
          renderItem: item => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd_es_list__WEBPACK_IMPORTED_MODULE_5__["default"].Item, {
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxDEV)(antd_es_space__WEBPACK_IMPORTED_MODULE_6__["default"], {
              children: item
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 29,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 15,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 9
  }, undefined);
};
_c = App;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);
var _c;
__webpack_require__.$Refresh$.register(_c, "App");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("902980ad87e9b8ad55f1")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=popup.0c9368e7e62f9cde0594.hot-update.js.map