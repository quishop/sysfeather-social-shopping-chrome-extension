globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("all",{

/***/ "./src/contents/all/ClassTable.ts":
/*!****************************************!*\
  !*** ./src/contents/all/ClassTable.ts ***!
  \****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "classTable": () => (/* binding */ classTable)
/* harmony export */ });
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js */ "./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js");

let classTable = {
  author: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys d1544ag0 qt6c0cv9 tw6a2znq i1ao9s8h esuyzwwr f1sip0of lzcic4wl l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn e72ty7fz qlfml3jp inkptoze qmr60zad btwxx1t3 tv7at329 taijpn5t k4urcfbm', 'x6s0dn4 x78zum5 x5yr21d xl56j7k x1emribx xfff67h xu1161g x12ca73t x5vlmd'],
  group_name: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db a5q79mjw g1cxx5fr ekzkrbhg oo9gr5id hzawbc8m', 'd2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 embtmqzv fe6kdd0r mau55g9w c8b282yb hrzyx87i m6dqt4wy h7mekvxk hnhda86s oo9gr5id hzawbc8m', 'oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl gmql0nx0 gpro0wi8 hnhda86s', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn bdao358l fsf7x5fv rse6dlih s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk srn514ro oxkhqvkx rl78xhln nch0832m cr00lzj9 rn8ck1ys s3jn8y49 icdlwmnq jxuftiz4 cxfqmxzd o48pnaf2', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz x1heor9g xt0b8zv x1xlr1w8', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz x1heor9g xt0b8zv x1xlr1w8'],
  //貼文列表
  postList: ['x9f619 x1n2onr6 x1ja2u2z xeuugli xs83m0k x1xmf6yo x1emribx x1e56ztr x1i64zmx xjl7jj x19h7ccj xu9j1y6 x7ep2pv'],
  // 貼文標題。
  // 貼文標題裡面有貼文作者姓名和貼文時間。
  // 單篇更新按鈕也是放在貼文標題裡面。
  postClass: ['pybr56ya dati1w0a hv4rvrfc n851cfcs btwxx1t3 j83agx80 ll8tlv6m', 'hael596l alzwoclg jl2a5g8c qjfq86k5 r227ecj6 gt60zsk1 s1m0hq7j',
  // 原結構：div > div
  'x1cy8zhl x78zum5 x1q0g3np xod5an3 x1pi30zi x1swvt13 xz9dl7a'],
  postName: ['nc684nl6'],
  // 展開貼文"顯示更多"按鈕
  postContentMore: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl oo9gr5id gpro0wi8 lrazzd5p', 'oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl gmql0nx0 gpro0wi8', 'qi72231t nu7423ey tav9wjvu flwp5yud tghlliq5 gkg15gwv s9ok87oh s9ljgwtm lxqftegz bf1zulr9 frfouenu bonavkto djs4p424 r7bn319e bdao358l fsf7x5fv tgm57n0e s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk dnr7xe2t aeinzg81 srn514ro rl78xhln nch0832m om3e55n1 cr00lzj9 rn8ck1ys s3jn8y49 g4tp4svg o9erhkwx dzqi5evh hupbnkgi hvb2xoa8 fxk3tzhb jl2a5g8c f14ij5to icdlwmnq i85zmo3j rtxb060y cgu29s5g i15ihif8 i5oewl5a cxfqmxzd', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf tb6i94ri gupuyl1y i2onq4tn b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas f5mw3jnl hxfwr5lz k1z55t6l oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf exr7barw b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas m2nijcs8 hxfwr5lz k1z55t6l oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf tb6i94ri gupuyl1y i2onq4tn b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas f5mw3jnl hxfwr5lz c61n2bf6 oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf exr7barw b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas m2nijcs8 hxfwr5lz c61n2bf6 oog5qr5w innypi6y rtxb060y', 'x1i10hfl xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1a2a7pz x6s0dn4 xi81zsa x1iyjqo2 xs83m0k xsyo7zv xt0b8zv', 'x78zum5 x1iyjqo2 x21xpn4 x1n2onr6',
  // 原結構：div > div > div
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f'],
  // 貼文內容
  postContent: ['dati1w0a ihqw7lf3 hv4rvrfc ecm0bbzt', 'j83agx80 cbu4d94t ew0dbk1b irj2b8pg', 'qt6c0cv9 hv4rvrfc dati1w0a jb3vyjys', 'kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x c1et5uql', 'd2hqwtrz r227ecj6 ez8dtbzv gt60zsk1', 'm8h3af8h l7ghb35v kjdc1dyq kmwttqpk gh25dzvf', 'x1pi30zi x1swvt13 xexx8yu x18d9i69',
  // 原結構：div > div
  'x1iorvi4 x1pi30zi x1l90r2v x1swvt13', 'x1iorvi4 x1pi30zi xjkvuk6 x1swvt13'],
  postCommit: ['rq0escxv l9j0dhe7 du4w35lb j83agx80 g5gj957u rj1gh0hx buofh1pr hpfvmrgz taijpn5t bp9cbjyn owycx6da btwxx1t3 d1544ag0 tw6a2znq jb3vyjys dlv3wnog rl04r1d5 mysgfdmx hddg9phg qu8okrzs g0qnabr5'],
  // 貼文四區塊當中的留言顯示區塊
  // 包含：留言數量、按讚按鈕、留言和輸入框
  postCommitDiv: [
  // 原結構：div > div > div
  'x10wlt62 x6ikm8r x9jhf4c x30kzoy x13lgxp2 x168nmei'],
  postViewCommitCommit: ['oajrlxb2 bp9cbjyn g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv nhd2j8a9 pq6dq46d mg4g778l btwxx1t3 g5gj957u p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys p8fzw8mz qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb lzcic4wl abiwlrkh gpro0wi8 m9osqain buofh1pr', 'x1i10hfl xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 xe8uvvx xdj266r x11i5rnm xat24cr x2lwn1j xeuugli xexx8yu x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1a2a7pz x6s0dn4 xi81zsa x1iyjqo2 xs83m0k xsyo7zv xt0b8zv x1mnrxsn', 'x1i10hfl xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1a2a7pz x6s0dn4 xi81zsa x1iyjqo2 xs83m0k xsyo7zv xt0b8zv'],
  postViewCommitLoad: ['oajrlxb2 bp9cbjyn g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv e3zaq2ox pq6dq46d mg4g778l btwxx1t3 g5gj957u p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys p8fzw8mz qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb lzcic4wl abiwlrkh gpro0wi8 m9osqain buofh1pr'],
  // 留言時間
  // 透過留言時間可以拿到貼文url
  commentTime: [
  // 原結構：li > a[href]
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa x1fcty0u', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm'],
  // 留言時間
  // 透過留言時間可以拿到貼文url
  postTimeID: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl m9osqain gpro0wi8 knj5qynh', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn bdao358l fsf7x5fv rse6dlih s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk srn514ro oxkhqvkx rl78xhln nch0832m cr00lzj9 rn8ck1ys s3jn8y49 icdlwmnq cxfqmxzd rtxb060y gh55jysx', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa x1fcty0u', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm'],
  // 貼文留言數量
  FBPostCommit: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v knj5qynh m9osqain',
  // 原結構：div > span
  /* mac */
  'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa', /* windows */'x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa'],
  //一個留言的區塊
  postCommitNode: ['tw6a2znq sj5x9vvc d1544ag0 cxgpxx05', 'jg3vgc78 cgu29s5g lq84ybu9 hf30pyar r227ecj6', 'x1r8uery x1iyjqo2 x6ikm8r x10wlt62 x1pi30zi', 'xmjcpbm x1tlxs6b x1g8br2z x1gn5b1j x230xth x9f619 xzsf02u x1rg5ohu xdj266r x11i5rnm xat24cr x1mh8g0r x193iq5w x1mzt3pk x1n2onr6 xeaf4i8 x13faqbe'],
  postCommitContent: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v knj5qynh oo9gr5id', 'kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x c1et5uql', 'd2hqwtrz o9wcebwi b6ax4al1', 'x1iorvi4 xjkvuk6 x1lliihq'],
  // 貼文所有留言、最新或最相關留言按鈕
  postCommitState: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v lrazzd5p m9osqain', 'd2edcug0 hpfvmrgz qv66sw1b c1et5uql oi732d6d ik7dh3pa ht8s03o8 a8c37x1j fe6kdd0r mau55g9w c8b282yb keod5gw0 nxhoafnm aigsh9s9 d9wwppkn iv3no6db jq4qci2q a3bd9o3v lrazzd5p m9osqain', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn bdao358l fsf7x5fv rse6dlih s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk srn514ro oxkhqvkx rl78xhln nch0832m cr00lzj9 rn8ck1ys s3jn8y49 o9erhkwx dzqi5evh hupbnkgi hvb2xoa8 om3e55n1 f14ij5to l3ldwz01 icdlwmnq',
  // 原結構：div > div
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x1n2onr6 x87ps6o x1lku1pv x1a2a7pz', 'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x3x7a5m x6prxxf xvq8zen x1s688f xi81zsa'],
  // 貼文所有留言、最新或最相關留言按鈕
  postCommitlastState: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 oi9244e8 oygrvhab h676nmdw pybr56ya dflh9lhu f10w8fjw scb9dxdr i1ao9s8h esuyzwwr f1sip0of lzcic4wl l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn dwo3fsh8 btwxx1t3 pfnyh3mw du4w35lb', 'oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 opuu4ng7 oygrvhab kj2yoqh6 pybr56ya dflh9lhu f10w8fjw scb9dxdr i1ao9s8h esuyzwwr f1sip0of lzcic4wl n00je7tq arfg74bv qs9ysxi8 k77z8yql l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn dwo3fsh8 btwxx1t3 pfnyh3mw du4w35lb', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn s5oniofx rn8ck1ys s3jn8y49 o9erhkwx dzqi5evh hupbnkgi hvb2xoa8 f14ij5to l3ldwz01 icdlwmnq qgrdou9d bdao358l fsf7x5fv alzwoclg jl2a5g8c jez8cy9q sb3qexpo l7miuv0d m8h3af8h kjdc1dyq s1m0hq7j b0eko5f3 rj2hsocd fwlpnqze om3e55n1 cr00lzj9 g4tp4svg i85zmo3j', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s x1w4qvff x13mpval xdj266r xat24cr xz9dl7a x1sxyh0 xsag5q8 xurb0ha x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s xnqzcj9 x1gh759c xdj266r xat24cr x1344otq x1de53dj xz9dl7a xsag5q8 x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s xnqzcj9 x1gh759c xdj266r xat24cr x1344otq x1de53dj xz9dl7a xsag5q8 x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4'],
  // 貼文所有留言、最新或最相關留言按鈕
  postCommitlast: ['du4w35lb l9j0dhe7 cbu4d94t j83agx80', 'bdao358l k0kqjr44 kj5i7le4 g6da2mms yn3a2qjl b52o6v01 a96hb305 lq84ybu9 hf30pyar', 'xu96u03 xm80bdy x10l6tqk x13vifvy'],
  checkGetHeaderUrlClass: ['xu06os2 x1ok221b', 'x1i10hfl'],
  checkGetPostHeaderClass: ['xu06os2 x1ok221b', 'x1i10hfl'],
  checkGetImageClass: ['x1n2onr6',
  // 原結構：div > img
  'x1ey2m1c xds687c x5yr21d x10l6tqk x17qophe x13vifvy xh8yej3'],
  checkCommitstatsClass: ['x1jx94hy'],
  checkUlNotClass: ['fop5sh7t', 'cgat1ltu', 'tv7at329', 'j83agx80', 'c4hnarmi', 'bp9cbjyn dy70pwuf', 'b7mnygb8', 'jvc6uz2b', 'alzwoclg', 'dsake333', 'i85zmo3j', 'xp7jhwk xw3qccf xc9qbxq x78zum5 xpvyfi4 x6s0dn4'],
  // CommentUlClass 是整篇留言最外層的DIV
  CommentUlClass: [
  // 原結構：div > div
  'x1jx94hy x12nagc'],
  // CommentDiv 是整篇留言最外層的DIV
  CommentDiv: [
  // 原結構：div > div
  'x1gslohp'],
  //每一個留言的DIV
  OneCommentDiv: [
  // 原結構：div > div
  'x78zum5 xdt5ytf'],
  // 貼文標題作者
  // 透過貼文標題作者a[href] 可以取得貼文作者ID
  postAuthor: [
  // 原結構：span.xt0psk2 > a[href]
  // .xt0psk2{display:inline}
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f'],
  // 沒有權限的貼文會顯示"目前無法查看此內容"訊息。
  deniedPost: [
  // 原結構：div.xzueoph.x1k70j0n > span
  // .x1k70j0n{margin-top:6px}
  // .xzueoph{margin-bottom:6px}
  'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x41vudc x1603h9y x1u7k74 x1xlr1w8 xi81zsa x2b8uid'],
  oneCommentClass: ['x169t7cy x19f6ikt'],
  // unuse wait for next patch
  // secondCommentClass: [
  //   "x1n2onr6 x46jau6"
  // ],

  // thirdCommentClass: [
  //   "x1n2onr6 x1xb5h2r"
  // ],

  postCommentSortClass: ['x1jx94hy x12nagc', 'x2bj2ny x12nagc', 'x6s0dn4 x78zum5 xdj266r x11i5rnm xat24cr x1mh8g0r xe0p6wg'],
  //粉絲頁貼文列表
  pagePostList: ['x9f619 x1n2onr6 x1ja2u2z xeuugli xs83m0k x1xmf6yo x1emribx x1e56ztr x1i64zmx xjl7jj x19h7ccj xu9j1y6 x7ep2pv', 'x6s0dn4 x78zum5 xdt5ytf x193iq5w x1t2pt76 xh8yej3', 'x2bj2ny x78zum5 xds687c xdt5ytf xnjgh8c xixxii4 x1qrby5j xjabf5u xfmqk8h xxzkxad' //這個是直接監控直播貼文
  ],
  // //page class
  pagePostClass: [
  // 原結構：div > div
  'x1cy8zhl x78zum5 x1q0g3np xod5an3 x1pi30zi x1swvt13 xz9dl7a',
  //page Live Header
  'x78zum5 xdt5ytf x2lah0s xyamay9 x1pi30zi x18d9i69 x1swvt13'],
  pagePostAuthor: [
  // 原結構：span.xt0psk2 > a[href]
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f'],
  pagePostCommitDiv: [
  // 原結構：div > div > div
  'x10wlt62 x6ikm8r x9jhf4c x30kzoy x13lgxp2 x168nmei', 'x168nmei x13lgxp2 x30kzoy x9jhf4c x6ikm8r x10wlt62',
  // page live post
  'x78zum5 xdt5ytf xtp0wl1'],
  pageCommentTime: [
  // 原結構：li > a[href]
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa x1fcty0u', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm'],
  pageNameNode: ['x1cy8zhl x78zum5 x1q0g3np xod5an3 x1pi30zi x1swvt13 xz9dl7a', 'x78zum5 xdt5ytf x2lah0s xyamay9 x1pi30zi x18d9i69 x1swvt13'],
  page_name: [
  //"x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f",
  'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa x1yc453h'],
  // 展開貼文"顯示更多"按鈕
  pagePostContentMore: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl oo9gr5id gpro0wi8 lrazzd5p', 'oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl gmql0nx0 gpro0wi8', 'qi72231t nu7423ey tav9wjvu flwp5yud tghlliq5 gkg15gwv s9ok87oh s9ljgwtm lxqftegz bf1zulr9 frfouenu bonavkto djs4p424 r7bn319e bdao358l fsf7x5fv tgm57n0e s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk dnr7xe2t aeinzg81 srn514ro rl78xhln nch0832m om3e55n1 cr00lzj9 rn8ck1ys s3jn8y49 g4tp4svg o9erhkwx dzqi5evh hupbnkgi hvb2xoa8 fxk3tzhb jl2a5g8c f14ij5to icdlwmnq i85zmo3j rtxb060y cgu29s5g i15ihif8 i5oewl5a cxfqmxzd', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf tb6i94ri gupuyl1y i2onq4tn b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas f5mw3jnl hxfwr5lz k1z55t6l oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf exr7barw b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas m2nijcs8 hxfwr5lz k1z55t6l oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf tb6i94ri gupuyl1y i2onq4tn b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas f5mw3jnl hxfwr5lz c61n2bf6 oog5qr5w innypi6y rtxb060y', 'gvxzyvdx aeinzg81 t7p7dqev gh25dzvf exr7barw b6ax4al1 gem102v4 ncib64c9 mrvwc6qr sx8pxkcf f597kf1v cpcgwwas m2nijcs8 hxfwr5lz c61n2bf6 oog5qr5w innypi6y rtxb060y', 'x1i10hfl xjbqb8w xjqpnuy xa49m3k xqeqjp1 x2hbi6w x13fuv20 xu3j5b3 x1q0q8m5 x26u7qi x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xdl72j9 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r x2lwn1j xeuugli xexx8yu x18d9i69 xkhd6sd x1n2onr6 x16tdsg8 x1hl2dhg xggy1nq x1ja2u2z x1t137rt x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x3nfvp2 x1q0g3np x87ps6o x1a2a7pz x6s0dn4 xi81zsa x1iyjqo2 xs83m0k xsyo7zv xt0b8zv', 'x78zum5 x1iyjqo2 x21xpn4 x1n2onr6',
  // 原結構：div > div > div
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xzsf02u x1s688f'],
  pagePostCommitNode: ['tw6a2znq sj5x9vvc d1544ag0 cxgpxx05', 'jg3vgc78 cgu29s5g lq84ybu9 hf30pyar r227ecj6', 'x1r8uery x1iyjqo2 x6ikm8r x10wlt62 x1pi30zi', 'xmjcpbm x1tlxs6b x1g8br2z x1gn5b1j x230xth x9f619 xzsf02u x1rg5ohu xdj266r x11i5rnm xat24cr x1mh8g0r x193iq5w x1mzt3pk x1n2onr6 xeaf4i8 x13faqbe'],
  pagePostCommitContent: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v knj5qynh oo9gr5id', 'kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x c1et5uql', 'd2hqwtrz o9wcebwi b6ax4al1', 'x1iorvi4 xjkvuk6 x1lliihq'],
  /*
  從留言時間的 拿取comment url
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[8]/div/div/div[4]/div/div/div[2]/ul/li[2]/div[1]/div/div[2]/div[2]/ul/li[3]/div/a
  */
  pagePostTimeID: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 nc684nl6 p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x jb3vyjys rz4wbd8a qt6c0cv9 a8nywdso i1ao9s8h esuyzwwr f1sip0of lzcic4wl m9osqain gpro0wi8 knj5qynh', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn bdao358l fsf7x5fv rse6dlih s5oniofx m8h3af8h l7ghb35v kjdc1dyq kmwttqpk srn514ro oxkhqvkx rl78xhln nch0832m cr00lzj9 rn8ck1ys s3jn8y49 icdlwmnq cxfqmxzd rtxb060y gh55jysx', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa x1fcty0u', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1a2a7pz xt0b8zv xi81zsa xo1l8bm'],
  pagePostViewCommitCommit: ['oajrlxb2 bp9cbjyn g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv nhd2j8a9 pq6dq46d mg4g778l btwxx1t3 g5gj957u p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys p8fzw8mz qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb lzcic4wl abiwlrkh gpro0wi8 m9osqain buofh1pr'],
  pagePostViewCommitLoad: ['oajrlxb2 bp9cbjyn g5ia77u1 mtkw9kbi tlpljxtp qensuy8j ppp5ayq2 goun2846 ccm00jje s44p3ltw mk2mc5f4 rt8b4zig n8ej3o3l agehan2d sk4xxmp2 rq0escxv e3zaq2ox pq6dq46d mg4g778l btwxx1t3 g5gj957u p7hjln8o kvgmc6g5 cxmmr5t8 oygrvhab hcukyx3x tgvbjcpo hpfvmrgz jb3vyjys p8fzw8mz qt6c0cv9 a8nywdso l9j0dhe7 i1ao9s8h esuyzwwr f1sip0of du4w35lb lzcic4wl abiwlrkh gpro0wi8 m9osqain buofh1pr'],
  /*
  抓取留言的數量 ?則留言
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[8]/div/div/div[4]/div/div/div[1]/div/div[1]/div/div[2]/div[2]/span/div/span
  */
  pageFBPostCommit: ['d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v knj5qynh m9osqain',
  // 原結構：div > span
  /* mac */
  'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa', /* windows */'x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen xo1l8bm xi81zsa'],
  pagePostCommit: ['rq0escxv l9j0dhe7 du4w35lb j83agx80 g5gj957u rj1gh0hx buofh1pr hpfvmrgz taijpn5t bp9cbjyn owycx6da btwxx1t3 d1544ag0 tw6a2znq jb3vyjys dlv3wnog rl04r1d5 mysgfdmx hddg9phg qu8okrzs g0qnabr5', 'x9f619 x1n2onr6 x1ja2u2z x78zum5 x1r8uery x1iyjqo2 xs83m0k xeuugli xl56j7k x6s0dn4 xozqiw3 x1q0g3np xn6708d x1ye3gou xexx8yu xcud41i x139jcc6 x4cne27 xifccgj xn3w4p2 xuxw1ft', 'x9f619 x1n2onr6 x1ja2u2z x78zum5 xdt5ytf x193iq5w xeuugli x1r8uery x1iyjqo2 xs83m0k xg83lxy x1h0ha7o x10b6aqq x1yrsyyn'],
  pagePostCommitState: [
  // 原結構：div > div
  'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x1n2onr6 x87ps6o x1lku1pv x1a2a7pz',
  /*
  Page Live
  找到切換留言的 btn
  /html/body/div[1]/div/div[1]/div/div[5]/div/div/div[3]/div[2]/div/div/div[2]/div[1]/div/div[1]/div/div/div[5]/div[1]/div[1]/div/div/div/span
  */
  'x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x xudqn12 x3x7a5m x6prxxf xvq8zen x1s688f xi81zsa', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n x9f619 x1ypdohk xt0psk2 xe8uvvx xdj266r x11i5rnm xat24cr x1mh8g0r xexx8yu x4uap5 x18d9i69 xkhd6sd x16tdsg8 x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x1n2onr6 x87ps6o x1lku1pv x1a2a7pz'],
  // 貼文所有留言、最新或最相關留言按鈕
  pagePostCommitlastState: ['oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 oi9244e8 oygrvhab h676nmdw pybr56ya dflh9lhu f10w8fjw scb9dxdr i1ao9s8h esuyzwwr f1sip0of lzcic4wl l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn dwo3fsh8 btwxx1t3 pfnyh3mw du4w35lb', 'oajrlxb2 g5ia77u1 qu0x051f esr5mh6w e9989ue4 r7d6kgcz rq0escxv nhd2j8a9 j83agx80 p7hjln8o kvgmc6g5 opuu4ng7 oygrvhab kj2yoqh6 pybr56ya dflh9lhu f10w8fjw scb9dxdr i1ao9s8h esuyzwwr f1sip0of lzcic4wl n00je7tq arfg74bv qs9ysxi8 k77z8yql l9j0dhe7 abiwlrkh p8dawk7l bp9cbjyn dwo3fsh8 btwxx1t3 pfnyh3mw du4w35lb', 'qi72231t nu7423ey n3hqoq4p r86q59rh b3qcqh3k fq87ekyn s5oniofx rn8ck1ys s3jn8y49 o9erhkwx dzqi5evh hupbnkgi hvb2xoa8 f14ij5to l3ldwz01 icdlwmnq qgrdou9d bdao358l fsf7x5fv alzwoclg jl2a5g8c jez8cy9q sb3qexpo l7miuv0d m8h3af8h kjdc1dyq s1m0hq7j b0eko5f3 rj2hsocd fwlpnqze om3e55n1 cr00lzj9 g4tp4svg i85zmo3j', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s x1w4qvff x13mpval xdj266r xat24cr xz9dl7a x1sxyh0 xsag5q8 xurb0ha x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4', 'x1i10hfl xjbqb8w x6umtig x1b1mbwd xaqea5y xav7gou xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s xnqzcj9 x1gh759c xdj266r xat24cr x1344otq x1de53dj xz9dl7a xsag5q8 x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4', 'x1i10hfl xjbqb8w x1ejq31n xd10rxx x1sy0etr x17r0tee x972fbf xcfux6l x1qhh985 xm0m39n xe8uvvx x1hl2dhg xggy1nq x1o1ewxj x3x9cwd x1e5q0jg x13rtm0m x87ps6o x1lku1pv x1a2a7pz xjyslct x9f619 x1ypdohk x78zum5 x1q0g3np x2lah0s xnqzcj9 x1gh759c xdj266r xat24cr x1344otq x1de53dj xz9dl7a xsag5q8 x1n2onr6 x16tdsg8 x1ja2u2z x6s0dn4'],
  // 貼文所有留言、最新或最相關留言按鈕
  pagePostCommitlast: ['du4w35lb l9j0dhe7 cbu4d94t j83agx80', 'bdao358l k0kqjr44 kj5i7le4 g6da2mms yn3a2qjl b52o6v01 a96hb305 lq84ybu9 hf30pyar', 'xu96u03 xm80bdy x10l6tqk x13vifvy'],
  /*
  page 留言 抓用戶名稱，避免抓到 頭號粉絲
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div/div/div/div/div/div/div/div/div/div/div/div/div/div[8]/div/div/div[4]/div/div/div[2]/ul/li[1]/div[1]/div/div[2]/div[1]/div[1]/div/div/div/div/span/a/span/span
  */
  pageMsgName: ['x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x676frb x1nxh6w3 x1sibtaa x1s688f xzsf02u', 'x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x1lliihq x1s928wv xhkezso x1gmr53x x1cpjm7i x1fgarty x1943h6x x4zkp8e x676frb x1nxh6w3 x1sibtaa x1s688f xzsf02u'],
  /*
  粉絲頁首頁標籤
  span>b
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[2]/div/div/div/div/div[4]/div[2]/div/div[1]/div[2]/div/div[1]/div/div/div/div/div[2]/div[2]/div/ul/div[1]/div[2]/div/div/div/span/div/span
  */
  checkPageTag: ['x9f619 x1n2onr6 x1ja2u2z x78zum5 x2lah0s x1nhvcw1 x1qjc9v5 xozqiw3 x1q0g3np xexx8yu xykv574 xbmpl8g x4cne27 xifccgj'],
  /*
  在 page 直播貼文 打開 直播貼文的留言 
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[2]/div/div[2]/div[1]/div[3]/div/div/div/div/div/div/div[3]/div[1]
  */
  livePostComment: ['x9f619 x1n2onr6 x1ja2u2z x78zum5 x1r8uery x1iyjqo2 xs83m0k xeuugli xl56j7k x6s0dn4 xozqiw3 x1q0g3np xn6708d x1ye3gou xexx8yu xcud41i x139jcc6 x4cne27 xifccgj xn3w4p2 xuxw1ft'],
  checkLive: ['x193iq5w xeuugli x13faqbe x1vvkbs x1xmvt09 x6prxxf xvq8zen xo1l8bm xi81zsa', 'x193iq5w xeuugli x13faqbe x1vvkbs xlh3980 xvmahel x1n0sxbx x6prxxf xvq8zen xo1l8bm xi81zsa'],
  // pageCommentDiv 是整篇留言最外層的DIV
  pageCommentDiv: ['x1gslohp'],
  pageOneCommentClass: ['x169t7cy x19f6ikt'],
  // pageLiveCommentDiv 是"直播貼文"整篇留言最外層的DIV
  pageLiveCommentDiv: ['x1iyjqo2 x1pi30zi x1swvt13'],
  // 第三層留言外面的node
  pageThirdOuterComments: [
  // 'x1n2onr6 x1xb5h2r'
  'x78zum5 xdt5ytf'],
  pageThirdCommentContents: ['x1n2onr6 xurb0ha x1iorvi4 x78zum5 x1q0g3np x1a2a7pz']
};
initial();
function initial() {
  for (const key in classTable) {
    classTable[key].forEach((el, index) => {
      console.log(el);
      classTable[key][index] = '.' + classTable[key][index].replaceAll(' ', '.');
    });
  }
}


// WEBPACK FOOTER //
// ./src/content/ClassTable.js

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./src/contents/all/index.tsx":
/*!************************************!*\
  !*** ./src/contents/all/index.tsx ***!
  \************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var webext_bridge__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webext-bridge */ "./node_modules/.pnpm/webext-bridge@5.0.5/node_modules/webext-bridge/dist/index.mjs");
/* harmony import */ var _style_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./style.scss */ "./src/contents/all/style.scss");
/* harmony import */ var _ClassTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ClassTable */ "./src/contents/all/ClassTable.ts");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js */ "./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js");


// // import { main } from './components/MainFixedWindow.js';


// import { htmlTable } from './HtmlTable';

// Intercept fetch requests
try {
  if (isFacebookPostUrl(window.location.href)) {
    // console.log('124');
    // let div = document.createElement('div');
    // div.id = 'myCustomUI';
    // div.innerHTML = '<h1>Hello, this is my custom UI!</h1>';
    // // Append the custom UI to the body of the page
    // document.body.appendChild(div);

    // // Optionally, inject some CSS
    // let style = document.createElement('style');

    // style.textContent = `
    //     #myCustomUI {
    //         position: fixed;
    //         top: 0;
    //         right: 0;
    //         background: white;
    //         border: 1px solid black;
    //         padding: 10px;
    //         z-index: 1000;
    //     }
    //     `;
    // document.head.appendChild(style);

    // sendMessage('hello-from-content-script', '123', 'background');
    getCreationTime(1).then(response => {
      const data = {
        author: getAuthorFromClass(),
        createTime: new Date(response * 1000),
        commentsLength: getFBCommitLength()
      };
      (0,webext_bridge__WEBPACK_IMPORTED_MODULE_0__.sendMessage)('hello-from-content-script', data, 'background');
    });
    fetchCommentsList();
    // for (const postCommitDiv of classTable.postCommitDiv) {
    //     const commitClass = document.querySelector('body').querySelector(postCommitDiv);
    //     if (commitClass) {
    //         this.postCommit = commitClass;
    //         break;
    //     }
    // }
    // const val = startFetchCommitComments(document.querySelector('body'), []);
    // console.log('test 123:', val);
    // console.log('test 123:', getContentFn());
  }
} catch (e) {
  console.log('error:', e);
}
function isFacebookPostUrl(url) {
  const regexPermalink = /^https:\/\/www\.facebook\.com\/groups\/(\d+)\/permalink\/(\d+)\/$/;
  const regexGroupPost = /^https:\/\/www\.facebook\.com\/groups\/(\d+)\/posts\/(\d+)\/$/;
  const regexPost = /^https:\/\/www\.facebook\.com\/(\d+)\/posts\/(\d+)\/$/;
  return regexPermalink.test(url) || regexPost.test(url) || regexGroupPost.test(url);
}

/**
 * - 取得貼文建立時間
 * @param {integer} funcType 使用的方法
 * @returns {Promise<string>} 時間字串
 */
async function getCreationTime(funcType) {
  let timeText = '';
  switch (funcType) {
    case 1:
      timeText = await getCreationTimeByPostHtml();
      break;
  }
  return timeText;
}

// 取得FB顯示留言長度
function getFBCommitLength() {
  let commitClass;
  for (const postCommitDiv of _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postCommitDiv) {
    commitClass = document.querySelector('body').querySelector(postCommitDiv);
    if (commitClass) {
      break;
    }
  }
  if (!commitClass) {
    throw 'nullPostCommit'; // 在Mode.js 捕捉初始化錯誤
  }
  let FBlength = 0;
  try {
    let FBPostCommit = null;
    for (let i = 0; i < _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.FBPostCommit.length; i++) {
      const element = _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.FBPostCommit[i];
      FBPostCommit = commitClass.querySelector(element);
      if (FBPostCommit) break;
    }
    let content = FBPostCommit.textContent;
    if (content.indexOf('則留言') != -1) {
      return parseInt(content.split('則留言')[0].replace(',', ''));
    }
  } catch (e) {}
  return FBlength;
}
async function getCreationTimeByPostHtml() {
  let postHtml = await getPostHtml();
  if (postHtml && postHtml.indexOf('publish_time\\":') != -1) {
    return postHtml.split('publish_time\\":')[1].split(',')[0];
  }
  return '';
}
async function getPostHtml() {
  const config = {
    headers: {
      Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'
    }
  };
  let response = null;
  try {
    const fetchResponse = await fetch(window.location.href, config);
    if (!fetchResponse.ok) {
      throw new Error(`HTTP error! Status: ${fetchResponse.status}`);
    }
    response = await fetchResponse.text(); // Assuming you want to get the response as text
  } catch (e) {
    console.error('Error fetching data:', e);
  }
  return response;
}
function getAuthorFromClass() {
  //不要異動到外層的author
  let classAuthor = {
    id: '',
    name: ''
  };

  //作者的連結
  // const author_link = document.querySelector('a[href="/me/"]')
  // if(author_link) {
  //   classAuthor.id = getUserID()
  //   classAuthor.name = author_link.textContent
  // }
  const scriptStringList = document.getElementsByTagName('script');
  let userInfo = getUserInfoSearchUserIDByScript(scriptStringList);
  classAuthor = userInfo;
  if (classAuthor.id == '') {
    classAuthor = getAccountUsersByScriptStringList(scriptStringList);
  }

  //若上方抓不到id 就從 &__user抓
  if (classAuthor.id == '') {
    classAuthor = getAccountUsersAtBottomUserByScriptStringList(scriptStringList);
  }
  return classAuthor;
}
function getUserInfoSearchUserIDByScript(scriptStringList) {
  let userInfo = {
    id: '',
    name: ''
  };
  try {
    for (let index = 0; index < scriptStringList.length; index++) {
      let startIndex = scriptStringList[index].textContent.indexOf('"USER_ID":"');
      let endIndex = scriptStringList[index].textContent.indexOf(',"SHORT_NAME":"');
      if (startIndex != -1 && endIndex != -1) {
        let userInfoStr = scriptStringList[index].textContent.substring(startIndex, endIndex);
        let userInfoJSON = JSON.parse(`{${userInfoStr}}`);
        userInfo.id = userInfoJSON['USER_ID'];
        userInfo.name = userInfoJSON['NAME'];
        break;
      }
    }
  } catch (error) {}
  return userInfo;
}

//專門處理的方法
function getAccountUsersByScriptStringList(scriptStringList) {
  let author = {
    id: '',
    name: ''
  };
  for (let index = 0; index < scriptStringList.length; index++) {
    let scriptStringListInner = scriptStringList[index].innerHTML;
    if (scriptStringListInner.search('account_user') >= 0) {
      let userString = extractUserStringByAccountUser(scriptStringListInner);
      const nodeUserJson = JSON.parse('{' + userString + '}');
      if (nodeUserJson) {
        author.id = nodeUserJson['account_user']['id'];
        try {
          author.name = nodeUserJson['account_user']['short_name'];
        } catch (e) {
          author.name = '';
        }
        break;
      }
    }
  }
  return author;
}
function extractUserStringByAccountUser(scriptString) {
  const userStringStart = scriptString.search('"account_user');
  const userStringEnd = scriptString.search('"extensions');
  if (userStringStart > 0 && userStringEnd > 0) {
    const userStringLength = userStringEnd - userStringStart - 3;
    return scriptString.substr(userStringStart, userStringLength);
  }
  return null;
}
function getAccountUsersAtBottomUserByScriptStringList(scriptStringList) {
  let author = {
    id: '',
    name: ''
  };
  for (let index = 0; index < scriptStringList.length; index++) {
    let scriptStringListInner = scriptStringList[index].innerHTML;
    if (scriptStringListInner.search('&__user=') >= 0) {
      const userIdString = extractUserStringByBottomUser(scriptStringListInner);
      if (userIdString) {
        author.id = userIdString;
        break;
      }
    }
  }
  return author;
}
function extractUserStringByBottomUser(scriptString) {
  const userStringStart = scriptString.search('&__user=');
  const userStringEnd = scriptString.search('&__comet_req=');
  if (userStringStart > 0 && userStringEnd > 0) {
    const userStringLength = userStringEnd - userStringStart;
    const userString = scriptString.substr(userStringStart, userStringLength);
    return userString.replace('&__user=', '');
  }
  return null;
}
function fetchCommentsList() {
  // var unorderedList = nodes.querySelector('ul:not([class])');
  let node;

  // while (!node) {
  for (const pagePostCommitClass of _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.pagePostCommitDiv) {
    const pagePostCommitDiv = document.querySelector('body').querySelector(pagePostCommitClass);
    if (pagePostCommitDiv) {
      node = pagePostCommitDiv;
      break;
    }
  }
  // }

  console.log('node:', node);
  var unorderedList = node.querySelector('ul:not([class])');
  let check_style = true;
  if (unorderedList) {} else {
    for (const commentDiv of _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.CommentDiv) {
      unorderedList = node.querySelector('div' + commentDiv);
      if (unorderedList) {
        break;
      }
    }
  }
  console.log('unorderedList:', unorderedList);
  let oneComments = '';
  const res = [];
  for (const OneCommentDiv of _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.OneCommentDiv) {
    oneComments = unorderedList.querySelectorAll('div' + OneCommentDiv);
    if (oneComments) {
      break;
    }
  }
  console.log('oneComments:', oneComments);
  for (const oneComment of oneComments) {
    if (oneComment.hasAttribute('style')) {
      check_style = false;
      break;
    }
  }
}

// 檢查是否還有更多留言按鈕。
// 回傳true 表示點擊按鈕，畫面可能會變動。
function clickcheckMore(nodes) {
  //留言內的點擊更多的CSS
  /*
  /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[2]/div/div/div[4]/div/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[8]/div/div[4]/div/div/div[2]/div[2]/div[1]/div[2]/span/span
  */
  let postContentMoreElements = nodes.querySelectorAll(_ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postContentMore);
  let count = 0;
  //篩選一模一樣的關鍵字點擊展開
  for (let i = 0; i < postContentMoreElements.length; i++) {
    const element = postContentMoreElements[i];
    for (let j = 0; j < htmlTable.postCommitMore.length; j++) {
      if (element.textContent == htmlTable.postCommitMore[j]) {
        if (element.textContent.indexOf('隱藏') == '-1') {
          count++;
          element.click();
        }
      }
    }

    //模糊篩選關鍵字點擊展開
    for (let k = 0; k < htmlTable.postCommitMoreFuzzy.length; k++) {
      if (element.textContent.indexOf(htmlTable.postCommitMoreFuzzy[k]) != '-1') {
        if (element.textContent.indexOf('隱藏') == '-1') {
          count++;
          element.click();
        }
      }
    }
    /*
    if(el.textContent.indexOf("則回覆") != "-1") {
    if(el.textContent.indexOf("檢視") != "-1") {
      count++
      el.click()
    }
    }
    if(el.textContent.indexOf("已回覆") != "-1") {
    if(el.textContent.indexOf("則回覆") != "-1") {
      count++
      el.click()
    }
    }
    */

    /*
    if (el.textContent == "查看更多" || el.textContent == "顯示更多") {
     count++
    el.click()
    }
    */
  }
  if (count != 0) {
    return true;
  } else {
    return false;
  }
}

// 檢查是否還有更多留言按鈕。
// 回傳true 表示點擊按鈕，畫面可能會變動。
function clickMoreCommit(nodes) {
  if (!nodes) {
    //等待檢查是否會有空值情況發生
    return false;
  }

  // let commitstats = null
  // //classTable.CommentUlClass 是整篇留言最外層的DIV
  // /*
  // /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[2]/div/div/div[4]/div/div/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[8]/div/div[4]/div/div/div[2]
  // */
  // for (let i = 0; i < classTable.CommentUlClass.length; i++) {
  //   if (nodes.querySelector(classTable.CommentUlClass[i])) {
  //     commitstats = nodes.querySelector(classTable.CommentUlClass[i])
  //   }
  // }
  // if (!commitstats) return true

  let moreCommit = null;
  for (let i = 0; i < _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitCommit.length; i++) {
    const element = _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitCommit[i];
    moreCommit = nodes.querySelector(element);
    if (moreCommit) break;
  }
  let loading = null;
  for (let i = 0; i < _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitLoad.length; i++) {
    const element = _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitLoad[i];
    loading = nodes.querySelector(element);
    if (loading) break;
  }
  if (!moreCommit && !loading) {
    return false;
  }
  let count = 0;
  let moreCommitArr = null;
  for (let i = 0; i < _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitCommit.length; i++) {
    const element = _ClassTable__WEBPACK_IMPORTED_MODULE_2__.classTable.postViewCommitCommit[i];
    moreCommitArr = nodes.querySelectorAll(element);
    if (moreCommitArr.length > 0) break;
  }
  for (let i = 0; i < moreCommitArr.length; i++) {
    const element = moreCommitArr[i];
    if (element.hasChildNodes() && element.textContent.indexOf('隱藏') == -1) {
      count++;
      element.click();
    }
  }
  if (count || loading) {
    return true;
  }
  return false;
}

// // 初始化抓留言list dom的地方
// function startFetchCommitComments(node, postDataComments) {
//     if (!checkCommentsNodeHasChild(node)) return;
//     let fetchData = {
//         node: node,
//         postDataComments: postDataComments,
//     };
//     fetchCommentsList(1, fetchData);
//     return;
// }

// /**
//  *  - 遞迴留言列表
//  * @param {integer} funcType - 使用方法
//  * @param {object} fetchData - 節點物件跟留言內容的籃子
//  * @returns
//  */
// function fetchCommentsList(funcType, fetchData) {
//     try {
//         switch (funcType) {
//             case 1:
//                 fetchByCommentsListNode(fetchData);
//                 break;
//         }
//     } catch (error) {
//         // console.log(error)
//     }

//     return;
// }

// /**
//  * - 遞迴留言列表的每個留言節點(含有頭像的)
//  * @param {object} fetchData - 節點物件跟留言內容的籃子
//  * @returns
//  */
// function fetchByCommentsListNode(fetchData) {
//     if (!checkCommentsNodeHasChild(fetchData.node)) return;
//     let commentsListNode = fetchData.node.childNodes;
//     commentsListNode.forEach((commentNode) => {
//         if (commentNode.nodeName == '#text') {
//             //do nothing
//         } else {
//             getComment(commentNode, fetchData.postDataComments);
//         }
//     });
// }

// //檢查留言列表dom節點是否為空若為空就終止
// function checkCommentsNodeHasChild(node) {
//     let check = true;

//     if (!node || !node.hasChildNodes()) {
//         check = false;
//     }

//     if (check) {
//         let commentChildNode = node.childNodes;
//         if (
//             commentChildNode.length == 0 ||
//             !commentChildNode ||
//             !commentChildNode[0].querySelector('div')
//             //li[0].querySelector("div").getAttribute("aria-label")
//         ) {
//             check = false;
//         }
//     }

//     return check;
// }

// /**
//  * - 取得留言內容 commentNode(留言完整節點) > commitComentNode(排除頭像) > messageNode(真正的文字節點)
//  * @param {node} commentNode - 留言節點
//  * @param {object} postDataComments - 留言內容籃子(push)
//  * @returns
//  */
// function getComment(commentNode, postDataComments) {
//     let commitCommentNode = getCommitCommentNode(1, commentNode);
//     if (!commitCommentNode) return;

//     let fbNameUrl = commitCommentNode.querySelector('a').href;
//     let commenterName = getCommenterName(1, commitCommentNode);
//     let commenterObj = getCommentInfoObj(1, fbNameUrl);
//     let fb_comment_from_id = commenterObj.id;
//     let fb_comment_from_nickname = commenterObj.nickname;

//     let message = getCommentMessage(1, commitCommentNode);
//     let commenturl = getCommentUrl(1, commentNode);
//     let id = getCommentId(1, commenturl);

//     //如果沒有完成勾勾，顯示備份中.. css
//     if (!commitCommentNode.querySelector('.buy_1_backend')) {
//         let span = document.createElement('span');
//         span.innerHTML += htmlTable.import;
//         commitCommentNode.after(' ');
//         commitCommentNode.innerHTML += htmlTable.import;
//     }

//     fbNameUrl =
//         fbNameUrl.indexOf('/?__cft__') != -1
//             ? fbNameUrl.split('/?__cft__')[0].replace('https://www.facebook.com', '')
//             : '';

//     let data = {
//         fb_user_name: encodeURI(commenterName),
//         fb_comment_from_id: encodeURI(fb_comment_from_id),
//         fb_comment_message: encodeURI(message.trim()),
//         fbnameurl: encodeURI(fbNameUrl),
//         fb_created_time: '',
//         fb_comment_from_nickname: encodeURI(fb_comment_from_nickname),
//         commenturl: encodeURI(commenturl),
//     };
//     //封鎖問題
//     if (fbNameUrl != '') {
//         if ([].indexOf(commenturl) !== -1) {
//             // 已存在不做事
//         } else {
//             postDataComments.push(data);
//             [].push(commenturl);
//         }
//     }

//     fetchChildCommentListByCommentNode(commentNode, postDataComments);

//     //這個看起來像是尋找本層有沒有漏找的留言?
//     if (commentNode.querySelectorAll('ul').length > 2) {
//         let fetchData = {
//             node: commentNode.querySelectorAll('ul')[1],
//             postDataComments: postDataComments,
//         };
//         fetchCommentsList(1, fetchData);
//     }
//     return;
// }

// /**
//  * - 找尋下一層留言節點
//  * @param {node} commentNode - 留言節點
//  * @param {object} postDataComments - 留言物件push
//  * @returns
//  */
// function fetchChildCommentListByCommentNode(commentNode, postDataComments) {
//     for (let i = 0; i < classTable.oneCommentClass.length; i++) {
//         let oneCommentClass = classTable.oneCommentClass[i];
//         let oneCommentByCommentNode = commentNode.querySelector(oneCommentClass);
//         if (oneCommentByCommentNode) {
//             //現在在第一層
//             fetchUnderOneCommentsListByCommentNode(oneCommentByCommentNode, postDataComments);
//         } else if (oneCommentByCommentNode == null) {
//             //找不到第一層的node，就去找第二層
//             fetchUnderSecondCommentsListByCommentNode(commentNode, postDataComments);
//         }
//     }

//     return;
// }

// //處理第一層下的所有回覆
// function fetchUnderOneCommentsListByCommentNode(commentNode, postDataComments) {
//     if (commentNode.childNodes[1].childNodes.length > 0) {
//         let fetchData = {
//             node: commentNode.childNodes[1],
//             postDataComments: postDataComments,
//         };
//         fetchCommentsList(1, fetchData);
//     }
//     return;
// }

// //處理第二層下的所有回覆
// function fetchUnderSecondCommentsListByCommentNode(commentNode, postDataComments) {
//     let allSecondComment = [];
//     let querySelect = '.x78zum5 .xdt5ytf';
//     // let querySelect = ".x1n2onr6 .x1xb5h2r"  //他是子層不能同時query喔！會重複抓取
//     if (commentNode.querySelectorAll(querySelect)) {
//         allSecondComment = commentNode.querySelectorAll(querySelect);
//         for (let second_temp = 0; second_temp < allSecondComment.length; second_temp++) {
//             if (allSecondComment[second_temp].childNodes.length > 0) {
//                 let secondCommentChildNodesLength = allSecondComment[second_temp].childNodes.length;
//                 let fetchData = {
//                     node: allSecondComment[second_temp].childNodes[
//                         secondCommentChildNodesLength - 1
//                     ],
//                     postDataComments: postDataComments,
//                 };
//                 fetchCommentsList(1, fetchData);
//             }
//         }
//     }
//     return;
// }

// /**
//  * 取得留言的form id
//  * @param {integer} funcType - 使用方法
//  * @param {string} commentUrl - 留言的url
//  * @returns {string}
//  */
// function getCommentId(funcType, commentUrl) {
//     let id = '';
//     switch (funcType) {
//         case 1:
//             id = this.getCommentIdByUrlSplitWord(commentUrl);
//             break;
//     }
//     return id;
// }

// /**
//  * - 取得留言的a_link
//  * @param {integer} funcType - 使用方法
//  * @param {node} commentNode - 注入節點
//  * @returns {string} - 留言的a_link
//  */
// function getCommentUrl(funcType, commentNode) {
//     let commentUrl = '';
//     switch (funcType) {
//         case 1:
//             commentUrl = getCommentUrlFromCommentTimeByCommentNode(commentNode);
//             break;
//     }
//     return commentUrl;
// }

// //從留言的時間超連結找出留言url
// function getCommentUrlFromCommentTimeByCommentNode(commentNode) {
//     let commentUrl = '';
//     //找留言時間的dom
//     let tmpPostTime = null;
//     for (let i = 0; i < classTable.postTimeID.length; i++) {
//         const element = classTable.postTimeID[i];
//         tmpPostTime = commentNode.querySelector(element);
//         if (tmpPostTime) break;
//     }

//     if (tmpPostTime) {
//         commentUrl =
//             tmpPostTime.href.indexOf('&__cft__') != -1 ? tmpPostTime.href.split('&__cft__')[0] : '';
//     } else {
//         commentUrl = '';
//     }

//     return commentUrl;
// }

// /**
//  *  - 取得留言者realId or nickName
//  * @param {integer} funcType - 使用方法
//  * @param {string} fbNameUrl - 注入節點
//  * @returns {obj} - 留言者的id，小名
//  */
// function getCommentInfoObj(funcType, fbNameUrl) {
//     let commenter = {
//         id: '',
//         nickname: '',
//     };
//     try {
//         switch (funcType) {
//             case 1:
//                 commenter = getCommenterIdAndNicknameFromNameUrl(fbNameUrl);
//                 break;
//         }
//     } catch (error) {}
//     return commenter;
// }

// //取得留言者者id與綽號
// function getCommenterIdAndNicknameFromNameUrl(fbNameUrl) {
//     let commenter = {
//         id: '',
//         nickname: '',
//     };

//     if (fbNameUrl.indexOf('user') != '-1') {
//         commenter.id = fbNameUrl.split('user')[1].split('/')[1];
//     } else if (fbNameUrl.indexOf('profile.php?') != '-1') {
//         commenter.id = fbNameUrl.split('id=')[1].split('&__cft__')[0];
//     } else {
//         commenter.nickname = fbNameUrl.split('?__cft__')[0].replace('https://www.facebook.com', '');
//     }

//     return commenter;
// }

// /**
//  * - 取得留言者名稱
//  * @param {integer} funcType - 使用方法
//  * @param {node} commitCommentNode - 注入節點
//  * @returns {string} - 留言者名稱
//  */
// function getCommenterName(funcType, commitCommentNode) {
//     let commenterName = '';
//     switch (funcType) {
//         case 1:
//             commenterName = commitCommentNode.querySelector('span').textContent;
//             break;
//     }
//     return commenterName;
// }

// /**
//  * - 取得留言者訊息
//  * @param {integer} funcType - 使用方法
//  * @param {node} commitCommentNode - 注入節點
//  * @returns {string} - 訊息
//  */
// function getCommentMessage(funcType, commitCommentNode) {
//     let message = '';
//     switch (funcType) {
//         case 1:
//             message = getMessageByMessageNode(
//                 getCommentMsgNodeByCommitCommentNode,
//                 commitCommentNode,
//             );
//             break;
//     }
//     return message;
// }

// //從留言的node中找出留言內容的區塊
// function getCommentMsgNodeByCommitCommentNode(commitCommentNode) {
//     let textNode = null;
//     for (let i = 0; i < classTable.postCommitContent.length; i++) {
//         const element = classTable.postCommitContent[i];
//         textNode = commitCommentNode.querySelector(element);
//         if (textNode) break;
//     }
//     return textNode;
// }

// /**
//  *
//  * @param {Function} msgFetcher - 用來取得留言的方法
//  * @param {node} commitCommentNode - 注入節點
//  * @returns {string} - 留言內容
//  */
// function getMessageByMessageNode(msgFetcher, commitCommentNode) {
//     let message = '';
//     let messageNode = msgFetcher(commitCommentNode);
//     if (messageNode) {
//         messageNode.childNodes.forEach((textNode) => {
//             message += textNode.innerText + '\n\n';
//         });
//     }
//     return message;
// }

// /**
//  * - 往下找到更精準的留言區塊(排除頭像)
//  * @param {integer} funcType - 使用方法
//  * @param {*} commentNode - 使用者留言的節點
//  * @returns {node} - 排除使用者頭像更精準的留言節點
//  */
// function getCommitCommentNode(funcType, commentNode) {
//     let commitCommentNode = null;
//     switch (funcType) {
//         case 1:
//             commitCommentNode = getCommmitCommentNodeByCommentNode(commentNode);
//             break;
//     }
//     return commitCommentNode;
// }

// //取得留言區塊排除頭像
// function getCommmitCommentNodeByCommentNode(commentNode) {
//     let commitCommentNode = null;
//     for (let i = 0; i < classTable.postCommitNode.length; i++) {
//         const nodeClass = classTable.postCommitNode[i];
//         commitCommentNode = commentNode.querySelector(nodeClass);
//         if (commitCommentNode) break;
//     }
//     return commitCommentNode;
// }

// //取得社團名稱div資訊
// async function getGroupNameClass() {
//     let groupName = null;
//     //取社團名稱(用社團名稱超連結的CSS)
//     /*
//     /html/body/div[1]/div/div[1]/div/div[3]/div/div/div/div[1]/div[1]/div[2]/div/div/div[1]/div[2]/div/div/div/div/div[1]/div/div/div/div[1]/div/div[1]/h1/span/a
//     */
//     for (let i = 0; i < classTable.group_name.length; i++) {
//         const groupNameNode = classTable.group_name[i];
//         groupName = document.querySelector(groupNameNode);
//         if (groupName) break;
//     }
//     return groupName;
// }

// /**
//  *
//  * @param {Node} targetNode 目標節點
//  * @returns {Node} 返回找到的節點
//  */
// function getTargetFromClassTablePost(targetNode) {
//     let target = null;
//     for (let i = 0; i < classTable.postClass.length; i++) {
//         target = targetNode.querySelectorAll(classTable.postClass[i]);
//         console.log('target:', targetNode, target, classTable.postClass[i]);
//         if (target.length > 0) break;
//     }
//     console.log('getTargetFromClassTablePost:', target, targetNode, classTable.postClass);
//     return target;
// }

// function getTargetPostClassFromDocumentBody() {
//     let postClass = getTargetFromClassTablePost(document.querySelector('body'));
//     console.log('postClass:', postClass);
//     return postClass;
// }

// function content(selector) {
//     const nodes = getTargetPostClassFromDocumentBody();
//     console.log('content:', nodes, selector);
//     let contentNodes = nodes.querySelector(selector);
//     return getContentText(contentNodes);
// }

// function getContentText(contentNode) {
//     console.log('getContentText:', contentNode);
//     if (contentNode !== null) {
//         if (contentNode.hasChildNodes()) {
//             let text = '';
//             contentNode.childNodes.forEach((element) => {
//                 text += getContentText(element);
//             });

//             if (contentNode.tagName != undefined && contentNode.tagName == 'DIV') {
//                 text += '\n';
//             }
//             return text;
//         } else if (!contentNode.hasChildNodes() && contentNode.tagName == 'BR') {
//             return '\n';
//         } else {
//             return contentNode.textContent;
//         }
//     }

//     return '';
// }

// function getContentFn() {
//     for (let i = 0; i < classTable.postContent.length; i++) {
//         let contentElement = classTable.postContent[i];
//         console.log('contentElement1:', contentElement);
//         const text = content(contentElement);
//         console.log('contentElement:', contentElement, text);
//         if (text && text.trim() != '點擊可標註商品') {
//             return text;
//         }
//     }

//     return '';
// }

/////////// content
//   // 取得 Header的資訊
//   async function getPostHeader() {
//     let postGroupInfo = postData.group_info
//     //用PO文人的姓名超連結取的PO文人ID

//     let postOwnerId = await getPostOwnerId()

//     postGroupInfo.fb_user_id = postOwnerId

//     let pageNameClass = await getPageNameClass()

//     let pageName = null
//     if(pageNameClass) {
//       pageName = pageNameClass.querySelector('strong')
//     }
//     try {
//       postGroupInfo.fb_group_name = pageName.textContent
//     } catch (error) { }
//     postGroupInfo.fb_user_name = postData.author.name

//     let fbPostNumInfoObj = await getPostNumInfo(1)

//     if(fbPostNumInfoObj.num) {
//       postGroupInfo.fb_post_num_new = fbPostNumInfoObj.num
//     } else {
//       // console.log('lost post num')
//     }

//     postGroupInfo.posturl = getRealPostUrl();
//     postGroupInfo.fb_post_id = postGroupInfo.fb_group_id + "_" + postGroupInfo.fb_post_num_new
//     postGroupInfo.time_obj = await getCreationTime(1)
//   }

// 取得貼文url
// function getPostUrl() {
//     const url = getPostUrlFromComment();
//     if (url) return url;

//     const header = getHeader();
//     let postUrl = null;
//     if (header && header.href) {
//         let hasPosts = header.href.match('.*/posts/.+');
//         let hasStory = header.href.match('.*?story_fbid=.+');
//         let hasVideos = header.href.match('.*/videos/.+');
//         if (hasPosts) {
//             postUrl = hasPosts[0];
//         } else if (hasStory) {
//             postUrl = hasStory[0];
//         } else if (hasVideos) {
//             postUrl = hasVideos[0];
//         }
//     }
//     return postUrl;
// }

// // 從留言時間取得貼文url
// function getPostUrlFromComment() {
//     let postUrl = null;
//     for (const commentTimeNode of classTable.pageCommentTime) {
//         const commentTimeClass = postCommit.querySelector(commentTimeNode);
//         if (commentTimeClass && commentTimeClass.href) {
//             let hasPosts = commentTimeClass.href.match('.*/posts/.+');
//             let hasStory = commentTimeClass.href.match('.*?story_fbid=.+');
//             let hasVideos = commentTimeClass.href.match('.*/videos/.+');
//             if (hasPosts) {
//                 postUrl = hasPosts[0];
//             } else if (hasStory) {
//                 postUrl = hasStory[0];
//             } else if (hasVideos) {
//                 postUrl = hasVideos[0];
//             }
//         }
//     }
//     return postUrl;
// }

// function getHeader(i) {
//     let node = postHeader
//     let header = ''

//     let headerHtml =
//       node.querySelectorAll("div.xu06os2.x1ok221b span.x4k7w5x.x1h91t0o a.x1i10hfl");

//     const pageUrlRegex = /^https\:\/\/www\.facebook\.com\/[^\/]+\/?\?.+$/;
//     for (let i = 0; i < headerHtml.length; i++) {
//       let isPageUrl = pageUrlRegex.test(headerHtml[i]);
//       if (headerHtml[i].href.search("posts") != -1) {
//         header = headerHtml[i];
//         break;
//       }
//       // Facebook 將連結網址隱藏起來，直到滑鼠連結上。
//       if (headerHtml[i].href.slice(-1) == "#") {
//         header = headerHtml[i];
//         break;
//       }
//       if (headerHtml[i].href.search("permalink") != -1) {
//         header = headerHtml[i];
//         break;
//       }

//       if (isPageUrl) {
//         header = headerHtml[i];
//         break;
//       }
//       if (headerHtml[i].href.search("videos") != -1) {
//         header = headerHtml[i];
//         break;
//       }

//     }

//     return header
//   }

// /**
//  *
//  * @param {function} domFetcher - 要從哪裡抓取字符
//  * @param {string} str - 要搜索的字。
//  * @returns {string} - 返回找到的组ID
//  */
// function getGroupIDFromScript(domFetcher, str) {
//     let id = '';

//     const firstScript = domFetcher(str);

//     if (firstScript) {
//         let start = firstScript.textContent.indexOf(str);
//         id = firstScript.textContent.substr(start + str.length).split('"')[0];
//     }

//     return id;
// }

// function getTargetDomFromDocumentScripts(str) {
//     const documentScripts = document.querySelectorAll('script');

//     for (let i = 0; i < documentScripts.length; i++) {
//         let scriptDom = documentScripts[i];
//         let start = scriptDom.textContent.indexOf(str);
//         if (start !== -1) return scriptDom;
//     }

//     return '';
// }

// function getGroupIDFromMeta(str) {
//     let groupId = '';
//     const documentScripts = document.getElementsByTagName('meta');
//     for (let i = 0; i < documentScripts.length; i++) {
//         if (documentScripts[i].getAttribute('property') == 'al:android:url') {
//             groupId = documentScripts[i].getAttribute('content').replace('fb://group/', '');
//             break;
//         }
//     }
//     return groupId;
// }

// function getGroupID() {
//     let groupId = '';
//     const searchStrings = ["{'groupID':'", '"groupID":"'];
//     try {
//         for (const str of searchStrings) {
//             if (groupId) {
//                 break;
//             }
//             groupId = getGroupIDFromScript(getTargetDomFromDocumentScripts, str);
//             if (!groupId) {
//                 groupId = getGroupIDFromMeta(str);
//             }
//         }
//     } catch (error) {
//         console.error(error);
//     }
//     return groupId;
// }

// function getUserID() {
//     let userId = '';
//     try {
//         let str = '"USER_ID":"';
//         userId = getUserIDFromScript(getTargetDomFromDocumentScripts, str);
//     } catch (error) {}
//     return userId;
// }

// /**
//  *
//  * @param {function} domFetcher - 要從哪裡抓取字符
//  * @param {string} str - 要搜索的字
//  * @returns {string} - 返回找到的组ID
//  */
// function getUserIDFromScript(domFetcher, str) {
//     let userId = '';
//     const firstScript = domFetcher(str);
//     if (firstScript) {
//         let start = firstScript.textContent.indexOf(str);
//         userId = firstScript.textContent.substr(start + str.length).split('"')[0];
//     }
//     return userId;
// }

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ }),

/***/ "./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js ***!
  \*****************************************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";


/* eslint-env browser */
/*
  eslint-disable
  no-console,
  func-names
*/

/** @typedef {any} TODO */

var normalizeUrl = __webpack_require__(/*! ./normalize-url */ "./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/normalize-url.js");
var srcByModuleId = Object.create(null);
var noDocument = typeof document === "undefined";
var forEach = Array.prototype.forEach;

/**
 * @param {function} fn
 * @param {number} time
 * @returns {(function(): void)|*}
 */
function debounce(fn, time) {
  var timeout = 0;
  return function () {
    // @ts-ignore
    var self = this;
    // eslint-disable-next-line prefer-rest-params
    var args = arguments;
    var functionCall = function functionCall() {
      return fn.apply(self, args);
    };
    clearTimeout(timeout);

    // @ts-ignore
    timeout = setTimeout(functionCall, time);
  };
}
function noop() {}

/**
 * @param {TODO} moduleId
 * @returns {TODO}
 */
function getCurrentScriptUrl(moduleId) {
  var src = srcByModuleId[moduleId];
  if (!src) {
    if (document.currentScript) {
      src = /** @type {HTMLScriptElement} */document.currentScript.src;
    } else {
      var scripts = document.getElementsByTagName("script");
      var lastScriptTag = scripts[scripts.length - 1];
      if (lastScriptTag) {
        src = lastScriptTag.src;
      }
    }
    srcByModuleId[moduleId] = src;
  }

  /**
   * @param {string} fileMap
   * @returns {null | string[]}
   */
  return function (fileMap) {
    if (!src) {
      return null;
    }
    var splitResult = src.split(/([^\\/]+)\.js$/);
    var filename = splitResult && splitResult[1];
    if (!filename) {
      return [src.replace(".js", ".css")];
    }
    if (!fileMap) {
      return [src.replace(".js", ".css")];
    }
    return fileMap.split(",").map(function (mapRule) {
      var reg = new RegExp("".concat(filename, "\\.js$"), "g");
      return normalizeUrl(src.replace(reg, "".concat(mapRule.replace(/{fileName}/g, filename), ".css")));
    });
  };
}

/**
 * @param {TODO} el
 * @param {string} [url]
 */
function updateCss(el, url) {
  if (!url) {
    if (!el.href) {
      return;
    }

    // eslint-disable-next-line
    url = el.href.split("?")[0];
  }
  if (!isUrlRequest( /** @type {string} */url)) {
    return;
  }
  if (el.isLoaded === false) {
    // We seem to be about to replace a css link that hasn't loaded yet.
    // We're probably changing the same file more than once.
    return;
  }
  if (!url || !(url.indexOf(".css") > -1)) {
    return;
  }

  // eslint-disable-next-line no-param-reassign
  el.visited = true;
  var newEl = el.cloneNode();
  newEl.isLoaded = false;
  newEl.addEventListener("load", function () {
    if (newEl.isLoaded) {
      return;
    }
    newEl.isLoaded = true;
    el.parentNode.removeChild(el);
  });
  newEl.addEventListener("error", function () {
    if (newEl.isLoaded) {
      return;
    }
    newEl.isLoaded = true;
    el.parentNode.removeChild(el);
  });
  newEl.href = "".concat(url, "?").concat(Date.now());
  if (el.nextSibling) {
    el.parentNode.insertBefore(newEl, el.nextSibling);
  } else {
    el.parentNode.appendChild(newEl);
  }
}

/**
 * @param {string} href
 * @param {TODO} src
 * @returns {TODO}
 */
function getReloadUrl(href, src) {
  var ret;

  // eslint-disable-next-line no-param-reassign
  href = normalizeUrl(href);
  src.some(
  /**
   * @param {string} url
   */
  // eslint-disable-next-line array-callback-return
  function (url) {
    if (href.indexOf(src) > -1) {
      ret = url;
    }
  });
  return ret;
}

/**
 * @param {string} [src]
 * @returns {boolean}
 */
function reloadStyle(src) {
  if (!src) {
    return false;
  }
  var elements = document.querySelectorAll("link");
  var loaded = false;
  forEach.call(elements, function (el) {
    if (!el.href) {
      return;
    }
    var url = getReloadUrl(el.href, src);
    if (!isUrlRequest(url)) {
      return;
    }
    if (el.visited === true) {
      return;
    }
    if (url) {
      updateCss(el, url);
      loaded = true;
    }
  });
  return loaded;
}
function reloadAll() {
  var elements = document.querySelectorAll("link");
  forEach.call(elements, function (el) {
    if (el.visited === true) {
      return;
    }
    updateCss(el);
  });
}

/**
 * @param {string} url
 * @returns {boolean}
 */
function isUrlRequest(url) {
  // An URL is not an request if

  // It is not http or https
  if (!/^[a-zA-Z][a-zA-Z\d+\-.]*:/.test(url)) {
    return false;
  }
  return true;
}

/**
 * @param {TODO} moduleId
 * @param {TODO} options
 * @returns {TODO}
 */
module.exports = function (moduleId, options) {
  if (noDocument) {
    console.log("no window.document found, will not HMR CSS");
    return noop;
  }
  var getScriptSrc = getCurrentScriptUrl(moduleId);
  function update() {
    var src = getScriptSrc(options.filename);
    var reloaded = reloadStyle(src);
    if (options.locals) {
      console.log("[HMR] Detected local css modules. Reload all css");
      reloadAll();
      return;
    }
    if (reloaded) {
      console.log("[HMR] css reload %s", src.join(" "));
    } else {
      console.log("[HMR] Reload all css");
      reloadAll();
    }
  }
  return debounce(update, 50);
};

/***/ }),

/***/ "./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/normalize-url.js":
/*!**********************************************************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/normalize-url.js ***!
  \**********************************************************************************************************************************************************/
/***/ ((module) => {

"use strict";


/* eslint-disable */

/**
 * @param {string[]} pathComponents
 * @returns {string}
 */
function normalizeUrl(pathComponents) {
  return pathComponents.reduce(function (accumulator, item) {
    switch (item) {
      case "..":
        accumulator.pop();
        break;
      case ".":
        break;
      default:
        accumulator.push(item);
    }
    return accumulator;
  }, /** @type {string[]} */[]).join("/");
}

/**
 * @param {string} urlString
 * @returns {string}
 */
module.exports = function (urlString) {
  urlString = urlString.trim();
  if (/^data:/i.test(urlString)) {
    return urlString;
  }
  var protocol = urlString.indexOf("//") !== -1 ? urlString.split("//")[0] + "//" : "";
  var components = urlString.replace(new RegExp(protocol, "i"), "").split("/");
  var host = components[0].toLowerCase().replace(/\.$/, "");
  components[0] = "";
  var path = normalizeUrl(components);
  return protocol + host + path;
};

/***/ }),

/***/ "./src/contents/all/style.scss":
/*!*************************************!*\
  !*** ./src/contents/all/style.scss ***!
  \*************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin

    if(true) {
      // 1715056674133
      var cssReload = __webpack_require__(/*! ../../../node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js */ "./node_modules/.pnpm/mini-css-extract-plugin@2.7.0_webpack@5.75.0_@swc+core@1.3.19_/node_modules/mini-css-extract-plugin/dist/hmr/hotModuleReplacement.js")(module.id, {"locals":false});
      module.hot.dispose(cssReload);
      module.hot.accept(undefined, cssReload);
    }
  

/***/ }),

/***/ "./node_modules/.pnpm/tiny-uid@1.1.2/node_modules/tiny-uid/index.js":
/*!**************************************************************************!*\
  !*** ./node_modules/.pnpm/tiny-uid@1.1.2/node_modules/tiny-uid/index.js ***!
  \**************************************************************************/
/***/ ((module) => {

const generator = (base) => (
	typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function'
		? () => {
			const num = crypto.getRandomValues(new Uint8Array(1))[0];
			return (num >= base ? num % base : num).toString(base)
		}
		: () => Math.floor(Math.random() * base).toString(base)
);

const uid = (length = 7, hex = false) => (
	Array.from({ length }, generator(hex ? 16 : 36)).join('')
);

// Legacy
module.exports = uid;
// ES6+
module.exports["default"] = uid;


/***/ }),

/***/ "./node_modules/.pnpm/webextension-polyfill@0.9.0/node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!********************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/webextension-polyfill@0.9.0/node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \********************************************************************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.9.0 - Fri Mar 25 2022 17:00:23 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (typeof globalThis != "object" || typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
    const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)"; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      }); // Keep track if the deprecation warning has been logged at least once.

      let loggedSendResponseDeprecationWarning = false;
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              if (!loggedSendResponseDeprecationWarning) {
                console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                loggedSendResponseDeprecationWarning = true;
              }

              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./node_modules/.pnpm/nanoevents@6.0.2/node_modules/nanoevents/index.js":
/*!******************************************************************************!*\
  !*** ./node_modules/.pnpm/nanoevents@6.0.2/node_modules/nanoevents/index.js ***!
  \******************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createNanoEvents": () => (/* binding */ createNanoEvents)
/* harmony export */ });
let createNanoEvents = () => ({
  events: {},
  emit(event, ...args) {
    ;(this.events[event] || []).forEach(i => i(...args))
  },
  on(event, cb) {
    ;(this.events[event] = this.events[event] || []).push(cb)
    return () =>
      (this.events[event] = (this.events[event] || []).filter(i => i !== cb))
  }
})


/***/ }),

/***/ "./node_modules/.pnpm/serialize-error@9.1.1/node_modules/serialize-error/index.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/.pnpm/serialize-error@9.1.1/node_modules/serialize-error/index.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NonError": () => (/* binding */ NonError),
/* harmony export */   "deserializeError": () => (/* binding */ deserializeError),
/* harmony export */   "serializeError": () => (/* binding */ serializeError)
/* harmony export */ });
class NonError extends Error {
	name = 'NonError';

	constructor(message) {
		super(NonError._prepareSuperMessage(message));
	}

	static _prepareSuperMessage(message) {
		try {
			return JSON.stringify(message);
		} catch {
			return String(message);
		}
	}
}

const commonProperties = [
	{
		property: 'name',
		enumerable: false,
	},
	{
		property: 'message',
		enumerable: false,
	},
	{
		property: 'stack',
		enumerable: false,
	},
	{
		property: 'code',
		enumerable: true,
	},
];

const toJsonWasCalled = Symbol('.toJSON was called');

const toJSON = from => {
	from[toJsonWasCalled] = true;
	const json = from.toJSON();
	delete from[toJsonWasCalled];
	return json;
};

const destroyCircular = ({
	from,
	seen,
	to_,
	forceEnumerable,
	maxDepth,
	depth,
}) => {
	const to = to_ || (Array.isArray(from) ? [] : {});

	seen.push(from);

	if (depth >= maxDepth) {
		return to;
	}

	if (typeof from.toJSON === 'function' && from[toJsonWasCalled] !== true) {
		return toJSON(from);
	}

	for (const [key, value] of Object.entries(from)) {
		// eslint-disable-next-line node/prefer-global/buffer
		if (typeof Buffer === 'function' && Buffer.isBuffer(value)) {
			to[key] = '[object Buffer]';
			continue;
		}

		// TODO: Use `stream.isReadable()` when targeting Node.js 18.
		if (value !== null && typeof value === 'object' && typeof value.pipe === 'function') {
			to[key] = '[object Stream]';
			continue;
		}

		if (typeof value === 'function') {
			continue;
		}

		if (!value || typeof value !== 'object') {
			to[key] = value;
			continue;
		}

		if (!seen.includes(from[key])) {
			depth++;

			to[key] = destroyCircular({
				from: from[key],
				seen: [...seen],
				forceEnumerable,
				maxDepth,
				depth,
			});
			continue;
		}

		to[key] = '[Circular]';
	}

	for (const {property, enumerable} of commonProperties) {
		if (typeof from[property] === 'string') {
			Object.defineProperty(to, property, {
				value: from[property],
				enumerable: forceEnumerable ? true : enumerable,
				configurable: true,
				writable: true,
			});
		}
	}

	return to;
};

function serializeError(value, options = {}) {
	const {maxDepth = Number.POSITIVE_INFINITY} = options;

	if (typeof value === 'object' && value !== null) {
		return destroyCircular({
			from: value,
			seen: [],
			forceEnumerable: true,
			maxDepth,
			depth: 0,
		});
	}

	// People sometimes throw things besides Error objects…
	if (typeof value === 'function') {
		// `JSON.stringify()` discards functions. We do too, unless a function is thrown directly.
		return `[Function: ${(value.name || 'anonymous')}]`;
	}

	return value;
}

function deserializeError(value, options = {}) {
	const {maxDepth = Number.POSITIVE_INFINITY} = options;

	if (value instanceof Error) {
		return value;
	}

	if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
		const newError = new Error(); // eslint-disable-line unicorn/error-message
		destroyCircular({
			from: value,
			seen: [],
			to_: newError,
			maxDepth,
			depth: 0,
		});
		return newError;
	}

	return new NonError(value);
}


/***/ }),

/***/ "./node_modules/.pnpm/webext-bridge@5.0.5/node_modules/webext-bridge/dist/index.mjs":
/*!******************************************************************************************!*\
  !*** ./node_modules/.pnpm/webext-bridge@5.0.5/node_modules/webext-bridge/dist/index.mjs ***!
  \******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Stream": () => (/* binding */ Stream),
/* harmony export */   "allowWindowMessaging": () => (/* binding */ allowWindowMessaging),
/* harmony export */   "getCurrentContext": () => (/* binding */ getCurrentContext),
/* harmony export */   "isInternalEndpoint": () => (/* binding */ isInternalEndpoint),
/* harmony export */   "onMessage": () => (/* binding */ onMessage),
/* harmony export */   "onOpenStreamChannel": () => (/* binding */ onOpenStreamChannel),
/* harmony export */   "openStream": () => (/* binding */ openStream),
/* harmony export */   "parseEndpoint": () => (/* binding */ parseEndpoint),
/* harmony export */   "sendMessage": () => (/* binding */ sendMessage),
/* harmony export */   "setNamespace": () => (/* binding */ setNamespace)
/* harmony export */ });
/* harmony import */ var nanoevents__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! nanoevents */ "./node_modules/.pnpm/nanoevents@6.0.2/node_modules/nanoevents/index.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/.pnpm/webextension-polyfill@0.9.0/node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var serialize_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! serialize-error */ "./node_modules/.pnpm/serialize-error@9.1.1/node_modules/serialize-error/index.js");
/* harmony import */ var tiny_uid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tiny-uid */ "./node_modules/.pnpm/tiny-uid@1.1.2/node_modules/tiny-uid/index.js");
// src/stream.ts


// src/internal.ts




// src/utils.ts

var ENDPOINT_RE = /^((?:background$)|devtools|popup|options|content-script|window)(?:@(\d+)(?:\.(\d+))?)?$/;
var parseEndpoint = (endpoint) => {
  const [, context2, tabId, frameId] = endpoint.match(ENDPOINT_RE) || [];
  return {
    context: context2,
    tabId: +tabId,
    frameId: frameId ? +frameId : void 0
  };
};
var isInternalEndpoint = ({ context: ctx }) => ["content-script", "background", "devtools"].includes(ctx);
var hasAPI = (nsps) => webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__[nsps];
var getBackgroundPageType = () => {
  var _a, _b, _c;
  const manifest = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.getManifest();
  if (typeof window === "undefined")
    return "background";
  const popupPage = ((_a = manifest.browser_action) == null ? void 0 : _a.default_popup) || ((_b = manifest.action) == null ? void 0 : _b.default_popup);
  if (popupPage) {
    const url = new URL(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.getURL(popupPage));
    if (url.pathname === window.location.pathname)
      return "popup";
  }
  if ((_c = manifest.options_ui) == null ? void 0 : _c.page) {
    const url = new URL(webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.getURL(manifest.options_ui.page));
    if (url.pathname === window.location.pathname)
      return "options";
  }
  return "background";
};

// src/internal.ts
var context = hasAPI("devtools") ? "devtools" : hasAPI("tabs") ? getBackgroundPageType() : hasAPI("extension") ? "content-script" : typeof document !== "undefined" ? "window" : null;
var runtimeId = tiny_uid__WEBPACK_IMPORTED_MODULE_2__();
var openTransactions = /* @__PURE__ */ new Map();
var onMessageListeners = /* @__PURE__ */ new Map();
var messageQueue = /* @__PURE__ */ new Set();
var portMap = /* @__PURE__ */ new Map();
var port = null;
var namespace;
var isWindowMessagingAllowed;
initIntercoms();
function setNamespace(nsps) {
  namespace = nsps;
}
function allowWindowMessaging(nsps) {
  isWindowMessagingAllowed = true;
  namespace = nsps;
}
function initIntercoms() {
  if (context === null)
    throw new Error("Unable to detect runtime context i.e webext-bridge can't figure out what to do");
  if (context === "window" || context === "content-script")
    window.addEventListener("message", handleWindowOnMessage);
  if (context === "content-script" && top === window) {
    port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.connect();
    port.onMessage.addListener((message) => {
      routeMessage(message);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      initIntercoms();
    });
  }
  if (context === "content-script" && top !== window) {
    port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.connect();
    port.onMessage.addListener((message) => {
      routeMessage(message);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      initIntercoms();
    });
  }
  if (context === "devtools") {
    const { tabId } = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.devtools.inspectedWindow;
    const name = `devtools@${tabId}`;
    port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.connect(void 0, { name });
    port.onMessage.addListener((message) => {
      routeMessage(message);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      initIntercoms();
    });
  }
  if (context === "popup" || context === "options") {
    const name = `${context}`;
    port = webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.connect(void 0, { name });
    port.onMessage.addListener((message) => {
      routeMessage(message);
    });
    port.onDisconnect.addListener(() => {
      port = null;
      initIntercoms();
    });
  }
  if (context === "background") {
    webextension_polyfill__WEBPACK_IMPORTED_MODULE_0__.runtime.onConnect.addListener((incomingPort) => {
      let portId = incomingPort.name || `content-script@${incomingPort.sender.tab.id}`;
      const portFrame = incomingPort.sender.frameId;
      if (portFrame)
        portId = `${portId}.${portFrame}`;
      const { context: context2, tabId: linkedTabId, frameId: linkedFrameId } = parseEndpoint(portId);
      if (!linkedTabId && context2 !== "popup" && context2 !== "options")
        return;
      portMap.set(portId, incomingPort);
      messageQueue.forEach((queuedMsg) => {
        if (queuedMsg.resolvedDestination === portId) {
          incomingPort.postMessage(queuedMsg.message);
          messageQueue.delete(queuedMsg);
        }
      });
      incomingPort.onDisconnect.addListener(() => {
        portMap.delete(portId);
      });
      incomingPort.onMessage.addListener((message) => {
        var _a;
        if ((_a = message == null ? void 0 : message.origin) == null ? void 0 : _a.context) {
          message.origin.tabId = linkedTabId;
          message.origin.frameId = linkedFrameId;
          routeMessage(message);
        }
      });
    });
  }
}
function routeMessage(message) {
  const { origin, destination } = message;
  if (message.hops.includes(runtimeId))
    return;
  message.hops.push(runtimeId);
  if (context === "content-script" && [destination, origin].some((endpoint) => (endpoint == null ? void 0 : endpoint.context) === "window") && !isWindowMessagingAllowed)
    return;
  if (!destination)
    return handleInboundMessage(message);
  if (destination.context) {
    if (context === "window") {
      return routeMessageThroughWindow(window, message);
    } else if (context === "content-script" && destination.context === "window") {
      message.destination = null;
      return routeMessageThroughWindow(window, message);
    } else if (["devtools", "content-script", "popup", "options"].includes(context)) {
      if (destination.context === "background")
        message.destination = null;
      return port.postMessage(message);
    } else if (context === "background") {
      const { context: destName, tabId: destTabId, frameId: destFrameId } = destination;
      const { tabId: srcTabId } = origin;
      if (destName !== "window") {
        message.destination = null;
      } else {
        message.destination.tabId = null;
      }
      let resolvedDestination = ["popup", "options"].includes(destName) ? destName : `${destName === "window" ? "content-script" : destName}@${destTabId || srcTabId}`;
      if (destFrameId)
        resolvedDestination = `${resolvedDestination}.${destFrameId}`;
      const destPort = portMap.get(resolvedDestination);
      if (destPort)
        destPort.postMessage(message);
      else
        messageQueue.add({ resolvedDestination, message });
    }
  }
}
async function handleInboundMessage(message) {
  const { transactionId, messageID, messageType } = message;
  const handleReply = () => {
    const transactionP = openTransactions.get(transactionId);
    if (transactionP) {
      const { err, data } = message;
      if (err) {
        const dehydratedErr = err;
        const errCtr = self[dehydratedErr.name];
        const hydratedErr = new (typeof errCtr === "function" ? errCtr : Error)(dehydratedErr.message);
        for (const prop in dehydratedErr)
          hydratedErr[prop] = dehydratedErr[prop];
        transactionP.reject(hydratedErr);
      } else {
        transactionP.resolve(data);
      }
      openTransactions.delete(transactionId);
    }
  };
  const handleNewMessage = async () => {
    let reply;
    let err;
    let noHandlerFoundError = false;
    try {
      const cb = onMessageListeners.get(messageID);
      if (typeof cb === "function") {
        reply = await cb({
          sender: message.origin,
          id: messageID,
          data: message.data,
          timestamp: message.timestamp
        });
      } else {
        noHandlerFoundError = true;
        throw new Error(`[webext-bridge] No handler registered in '${context}' to accept messages with id '${messageID}'`);
      }
    } catch (error) {
      err = error;
    } finally {
      if (err)
        message.err = (0,serialize_error__WEBPACK_IMPORTED_MODULE_1__.serializeError)(err);
      routeMessage({
        ...message,
        messageType: "reply",
        data: reply,
        origin: { context, tabId: null },
        destination: message.origin,
        hops: []
      });
      if (err && !noHandlerFoundError)
        throw reply;
    }
  };
  switch (messageType) {
    case "reply":
      return handleReply();
    case "message":
      return handleNewMessage();
  }
}
function assertInternalMessage(msg) {
}
async function handleWindowOnMessage({ data, ports }) {
  if (context === "content-script" && !isWindowMessagingAllowed)
    return;
  if (data.cmd === "__crx_bridge_verify_listening" && data.scope === namespace && data.context !== context) {
    const msgPort = ports[0];
    msgPort.postMessage(true);
  } else if (data.cmd === "__crx_bridge_route_message" && data.scope === namespace && data.context !== context) {
    const { payload } = data;
    assertInternalMessage(payload);
    if (context === "content-script") {
      payload.origin = {
        context: "window",
        tabId: null
      };
    }
    routeMessage(payload);
  }
}
function routeMessageThroughWindow(win, msg) {
  ensureNamespaceSet();
  const channel = new MessageChannel();
  const retry = setTimeout(() => {
    channel.port1.onmessage = null;
    routeMessageThroughWindow(win, msg);
  }, 300);
  channel.port1.onmessage = () => {
    clearTimeout(retry);
    win.postMessage({
      cmd: "__crx_bridge_route_message",
      scope: namespace,
      context,
      payload: msg
    }, "*");
  };
  win.postMessage({
    cmd: "__crx_bridge_verify_listening",
    scope: namespace,
    context
  }, "*", [channel.port2]);
}
function ensureNamespaceSet() {
  if (typeof namespace !== "string" || namespace.length === 0) {
    throw new Error(`webext-bridge uses window.postMessage to talk with other "window"(s), for message routing and stuff,which is global/conflicting operation in case there are other scripts using webext-bridge. Call Bridge#setNamespace(nsps) to isolate your app. Example: setNamespace('com.facebook.react-devtools'). Make sure to use same namespace across all your scripts whereever window.postMessage is likely to be used\``);
  }
}
function getCurrentContext() {
  return context;
}

// src/apis/onMessage.ts
function onMessage(messageID, callback) {
  onMessageListeners.set(messageID, callback);
}

// src/apis/sendMessage.ts

async function sendMessage(messageID, data, destination = "background") {
  const endpoint = typeof destination === "string" ? parseEndpoint(destination) : destination;
  const errFn = "Bridge#sendMessage ->";
  if (!endpoint.context)
    throw new TypeError(`${errFn} Destination must be any one of known destinations`);
  if (context === "background") {
    const { context: dest, tabId: destTabId } = endpoint;
    if (dest !== "background" && !destTabId)
      throw new TypeError(`${errFn} When sending messages from background page, use @tabId syntax to target specific tab`);
  }
  return new Promise((resolve, reject) => {
    const payload = {
      messageID,
      data,
      destination: endpoint,
      messageType: "message",
      transactionId: tiny_uid__WEBPACK_IMPORTED_MODULE_2__(),
      origin: { context, tabId: null },
      hops: [],
      timestamp: Date.now()
    };
    openTransactions.set(payload.transactionId, { resolve, reject });
    routeMessage(payload);
  });
}

// src/stream.ts
var _Stream = class {
  constructor(t) {
    this.handleStreamClose = () => {
      if (!this.isClosed) {
        this.isClosed = true;
        this.emitter.emit("closed", true);
        this.emitter.events = {};
      }
    };
    this.internalInfo = t;
    this.emitter = (0,nanoevents__WEBPACK_IMPORTED_MODULE_3__.createNanoEvents)();
    this.isClosed = false;
    if (!_Stream.initDone) {
      onMessage("__crx_bridge_stream_transfer__", (msg) => {
        const { streamId, streamTransfer, action } = msg.data;
        const stream = _Stream.openStreams.get(streamId);
        if (stream && !stream.isClosed) {
          if (action === "transfer")
            stream.emitter.emit("message", streamTransfer);
          if (action === "close") {
            _Stream.openStreams.delete(streamId);
            stream.handleStreamClose();
          }
        }
      });
      _Stream.initDone = true;
    }
    _Stream.openStreams.set(t.streamId, this);
  }
  get info() {
    return this.internalInfo;
  }
  send(msg) {
    if (this.isClosed)
      throw new Error("Attempting to send a message over closed stream. Use stream.onClose(<callback>) to keep an eye on stream status");
    sendMessage("__crx_bridge_stream_transfer__", {
      streamId: this.internalInfo.streamId,
      streamTransfer: msg,
      action: "transfer"
    }, this.internalInfo.endpoint);
  }
  close(msg) {
    if (msg)
      this.send(msg);
    this.handleStreamClose();
    sendMessage("__crx_bridge_stream_transfer__", {
      streamId: this.internalInfo.streamId,
      streamTransfer: null,
      action: "close"
    }, this.internalInfo.endpoint);
  }
  onMessage(callback) {
    return this.getDisposable("message", callback);
  }
  onClose(callback) {
    return this.getDisposable("closed", callback);
  }
  getDisposable(event, callback) {
    const off = this.emitter.on(event, callback);
    return Object.assign(off, {
      dispose: off,
      close: off
    });
  }
};
var Stream = _Stream;
Stream.initDone = false;
Stream.openStreams = /* @__PURE__ */ new Map();

// src/bridge.ts


var openStreams = /* @__PURE__ */ new Map();
var onOpenStreamCallbacks = /* @__PURE__ */ new Map();
var streamyEmitter = (0,nanoevents__WEBPACK_IMPORTED_MODULE_3__.createNanoEvents)();
onMessage("__crx_bridge_stream_open__", (message) => {
  return new Promise((resolve) => {
    const { sender, data } = message;
    const { channel } = data;
    let watching = false;
    let off = () => {
    };
    const readyup = () => {
      const callback = onOpenStreamCallbacks.get(channel);
      if (typeof callback === "function") {
        callback(new Stream({ ...data, endpoint: sender }));
        if (watching)
          off();
        resolve(true);
      } else if (!watching) {
        watching = true;
        off = streamyEmitter.on("did-change-stream-callbacks", readyup);
      }
    };
    readyup();
  });
});
async function openStream(channel, destination) {
  if (openStreams.has(channel))
    throw new Error("webext-bridge: A Stream is already open at this channel");
  const endpoint = typeof destination === "string" ? parseEndpoint(destination) : destination;
  const streamInfo = { streamId: tiny_uid__WEBPACK_IMPORTED_MODULE_2__(), channel, endpoint };
  const stream = new Stream(streamInfo);
  stream.onClose(() => openStreams.delete(channel));
  await sendMessage("__crx_bridge_stream_open__", streamInfo, endpoint);
  openStreams.set(channel, stream);
  return stream;
}
function onOpenStreamChannel(channel, callback) {
  if (onOpenStreamCallbacks.has(channel))
    throw new Error("webext-bridge: This channel has already been claimed. Stream allows only one-on-one communication");
  onOpenStreamCallbacks.set(channel, callback);
  streamyEmitter.emit("did-change-stream-callbacks");
}



/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/define property getters */
/******/ (() => {
/******/ 	// define getter functions for harmony exports
/******/ 	__webpack_require__.d = (exports, definition) => {
/******/ 		for(var key in definition) {
/******/ 			if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 				Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 			}
/******/ 		}
/******/ 	};
/******/ })();
/******/ 
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("74f1ac7e62d263bbbb8b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=all.642ff6dd6b60991db41d.hot-update.js.map