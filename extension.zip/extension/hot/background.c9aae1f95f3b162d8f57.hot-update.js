"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("66e4150060951f368596")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.c9aae1f95f3b162d8f57.hot-update.js.map