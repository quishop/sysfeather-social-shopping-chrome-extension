"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("1de5ee796e950c25ed7b")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.b929f50737e7a78c426b.hot-update.js.map