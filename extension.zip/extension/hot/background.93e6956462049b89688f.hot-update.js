"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("49f3fbefdba19a97c12e")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.93e6956462049b89688f.hot-update.js.map