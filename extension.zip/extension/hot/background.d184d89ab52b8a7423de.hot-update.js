"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("87caf5e37eccf95a13f5")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.d184d89ab52b8a7423de.hot-update.js.map