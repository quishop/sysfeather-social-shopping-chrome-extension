"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("b022e3881f09de902738")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.2984890dac9e8934b34c.hot-update.js.map