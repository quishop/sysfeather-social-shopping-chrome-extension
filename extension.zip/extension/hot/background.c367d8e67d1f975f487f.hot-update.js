"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("6cbb9fc0c95c23b7c7ed")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.c367d8e67d1f975f487f.hot-update.js.map