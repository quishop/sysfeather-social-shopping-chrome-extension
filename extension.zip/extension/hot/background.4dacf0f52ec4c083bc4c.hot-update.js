"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("d2edd8a4960049973462")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.4dacf0f52ec4c083bc4c.hot-update.js.map