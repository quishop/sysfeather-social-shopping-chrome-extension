"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("5574cf90bfb929ea5e7d")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.c027f70185f6451c1728.hot-update.js.map