"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("447e48b5523bc5e482ec")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.ce6f36d4d95045f7c3f0.hot-update.js.map