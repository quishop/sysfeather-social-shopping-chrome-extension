"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("841ef68fcfde18b035dc")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.cd15153e6cc454e97f30.hot-update.js.map