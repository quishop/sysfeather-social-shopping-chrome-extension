"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("9b70c876fa0590b3f86f")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.a22ee5f0273003c945b8.hot-update.js.map