"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("7210a54de3136a112bc1")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.79e7ff7c093757a727b9.hot-update.js.map