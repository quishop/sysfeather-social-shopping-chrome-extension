"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("324ff5c1986fe0921f98")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.c3462868257a335fb98f.hot-update.js.map