"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("22e0a3a99565b62a6cd9")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.e1a118330a0dc77b92c5.hot-update.js.map