"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("all",{

/***/ "./src/contents/all/components/ActionPanel/index.tsx":
/*!***********************************************************!*\
  !*** ./src/contents/all/components/ActionPanel/index.tsx ***!
  \***********************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var antd_es_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! antd/es/button */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/button/index.js");
/* harmony import */ var antd_es_typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! antd/es/typography */ "./node_modules/.pnpm/antd@5.0.1_react-dom@18.2.0_react@18.2.0__react@18.2.0/node_modules/antd/es/typography/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/.pnpm/react@18.2.0/node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _all_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../all/index */ "./src/contents/all/index.tsx");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-dev-runtime.js");
/* provided dependency */ var __react_refresh_utils__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js");
/* provided dependency */ var __react_refresh_error_overlay__ = __webpack_require__(/*! ./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js */ "./node_modules/.pnpm/@pmmmwh+react-refresh-webpack-plugin@0.5.10_@types+webpack@5.28.0_@swc+core@1.3.19__react-ref_udjohwpsfilfyzb5xmkmwc6pwm/node_modules/@pmmmwh/react-refresh-webpack-plugin/overlay/index.js");
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js */ "./node_modules/.pnpm/react-refresh@0.14.0/node_modules/react-refresh/runtime.js");





var _jsxFileName = "/Users/wadejhao/Documents/sysfeather-social-shopping-chrome-extension/src/contents/all/components/ActionPanel/index.tsx",
  _s = __webpack_require__.$Refresh$.signature();



const {
  Title
} = antd_es_typography__WEBPACK_IMPORTED_MODULE_3__["default"];
const ActionPanel = () => {
  _s();
  const [loadings, setLoadings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  function getPostDetail() {
    const fetchPostNumInfo = (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.getPostNumInfo)(1);
    const fetchPostOwner = (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.getPostOwner)();
    const fetchCreationTime = (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.getCreationTime)(1);
    const fetchCommentList = (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.fetchComments)();
    Promise.all([fetchPostNumInfo, fetchPostOwner, fetchCreationTime, fetchCommentList]).then(response => {
      const data = {
        group: {
          name: '',
          id: (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.getGroupID)()
        },
        author: response[1],
        createTime: new Date(response[2] * 1000),
        commentsLength: (0,_all_index__WEBPACK_IMPORTED_MODULE_1__.getFBCommitLength)(),
        post: response[0],
        comments: response[3]
      };
      console.log('data:', data);
      chrome.runtime.sendMessage({
        action: 'openChromeUrl',
        data: data
      }, response => {
        console.log(response.status);
      });
      // sendMessage('hello-from-content-script', JSON.stringify(data), 'background');
    }).catch(e => {
      console.log('error:', e);
    }).finally(() => {
      {
        setLoadings(false);
      }
    });
  }
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
    style: {
      position: 'fixed',
      top: '0',
      right: '20px',
      backgroundColor: 'white',
      border: '1px solid black',
      padding: '10px',
      zIndex: 1000,
      minWidth: '200px'
    },
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)("div", {
      style: {
        width: '100%',
        textAlign: 'center'
      },
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(Title, {
        level: 3,
        children: "\u7372\u53D6\u7559\u8A00"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 17
      }, undefined), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxDEV)(antd_es_button__WEBPACK_IMPORTED_MODULE_4__["default"], {
        type: "primary",
        loading: loadings,
        onClick: () => {
          getPostDetail();
          setLoadings(true);
        },
        children: loadings ? '獲取中' : '開始'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 66,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 52,
    columnNumber: 9
  }, undefined);
};
_s(ActionPanel, "3daz0vG9ZF/120zrRtcq/XuSLJ4=");
_c = ActionPanel;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ActionPanel);
var _c;
__webpack_require__.$Refresh$.register(_c, "ActionPanel");

const $ReactRefreshModuleId$ = __webpack_require__.$Refresh$.moduleId;
const $ReactRefreshCurrentExports$ = __react_refresh_utils__.getModuleExports(
	$ReactRefreshModuleId$
);

function $ReactRefreshModuleRuntime$(exports) {
	if (true) {
		let errorOverlay;
		if (typeof __react_refresh_error_overlay__ !== 'undefined') {
			errorOverlay = __react_refresh_error_overlay__;
		}
		let testMode;
		if (typeof __react_refresh_test__ !== 'undefined') {
			testMode = __react_refresh_test__;
		}
		return __react_refresh_utils__.executeRuntime(
			exports,
			$ReactRefreshModuleId$,
			module.hot,
			errorOverlay,
			testMode
		);
	}
}

if (typeof Promise !== 'undefined' && $ReactRefreshCurrentExports$ instanceof Promise) {
	$ReactRefreshCurrentExports$.then($ReactRefreshModuleRuntime$);
} else {
	$ReactRefreshModuleRuntime$($ReactRefreshCurrentExports$);
}

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("7d28010b752a042dce38")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=all.86543cb6d4b31024decb.hot-update.js.map