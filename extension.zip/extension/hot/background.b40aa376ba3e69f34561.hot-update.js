"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("c03cb4688fb4c5fbc211")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.b40aa376ba3e69f34561.hot-update.js.map