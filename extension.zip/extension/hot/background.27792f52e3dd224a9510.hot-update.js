"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("27921e9851c8d1e5aef0")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.27792f52e3dd224a9510.hot-update.js.map