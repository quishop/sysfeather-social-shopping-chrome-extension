"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("979e43b2cc7f457a51fe")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.d283802d00e4badc180f.hot-update.js.map