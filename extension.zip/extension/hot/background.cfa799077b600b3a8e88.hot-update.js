"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("bc280fb41fbb1c6ba823")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.cfa799077b600b3a8e88.hot-update.js.map