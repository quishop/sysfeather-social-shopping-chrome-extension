"use strict";
globalThis["webpackHotUpdatesysfeather_social_shopping_chrome_extension"]("background",{},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("0f0f63b25792121e10d8")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=background.c438f5bc0dcedf0bc379.hot-update.js.map